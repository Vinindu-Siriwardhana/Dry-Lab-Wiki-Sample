"""G05 -- Model 5: free NO vs accumulated nitrite over the 24 h assay, at several V14 doses.
Two panels on separate axes (they differ by ~4 orders of magnitude) -- never a dual axis.
p65 from Model 4 (Tier-4 gamma, h) at a = A_LPS, K_D,P = 10.08 uM lower bound."""
import numpy as np
from common import *

KD = KD_UM                                  # uM, lower bound from params.py
t = np.linspace(0, 24 * 3600, 4000)
N_cell, q_max = 1e6, P.Q_CHRONIC           # as fig14 of the wiki bundle
doses = [(0, S.C_DERIVED), (25, "#4F8FC4"), (round(TGT_UM), S.C_V14), (1000, "#0B3C5D")]
fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.2, 4.0))
out = []
for C, col in doses:
    p65 = 0.85 * m.p65_scaled(C / KD, P.A_LPS, P.GAMMA, P.HILL_H) \
        / m.p65_scaled(0.0, P.A_LPS, P.GAMMA, P.HILL_H)
    R, NO, NO2 = m.inos_response(t, p65, N_cell, q_max, K_iNOS_rel=P.K_INOS_REL,
                                 p=P.P_INOS, k_turn=P.K_TURN, k_scav=P.K_SCAV,
                                 phi=P.PHI_NO2)
    lab = f"{C} µM V14" + ("  (LPS only)" if C == 0 else "  (target)" if C == round(TGT_UM) else "")
    ax.plot(t / 3600, NO / P.UM * 1e3, color=col, ls=S.LS_TIER4, label=lab)
    bx.plot(t / 3600, NO2 / P.UM, color=col, label=lab)
    out.append((C, p65, NO[-1] / P.UM * 1e3, NO2[-1] / P.UM))
for z in (ax, bx):
    z.set_xlim(0, 24); z.set_xticks([0, 6, 12, 18, 24]); z.set_xlabel("time after LPS  (h)")
    z.set_ylim(bottom=0)
ax.set_ylabel("free NO  (nM)")
bx.set_ylabel("accumulated nitrite  (µM)")
ax.set_title("(a)  Free NO  (quasi-steady)", loc="left", fontsize=10)
drop = 1 - out[2][3] / out[0][3]
bx.set_title("(b)  Accumulated nitrite  (Griess observable)", loc="left", fontsize=10)
bx.legend(loc="upper left", fontsize=7.8)
r24 = out[0][3] / (out[0][2] / 1e3)
bx.text(0.97, 0.05, f"at 24 h, nitrite ≈ {r24:,.0f}× free NO", transform=bx.transAxes,
        ha="right", fontsize=8.6, weight="bold", color=S.C_DERIVED)
S.tier4_note(ax, "dashed = rests on Tier-4 iNOS / scavenging priors", (0.98, 0.02))
fig.text(0.07, -0.03,
         "Single 24 h in-vitro stimulation (2×10$^5$ cells in 200 µL): V14 dose → p65 (Model 4) → iNOS → "
         "NO / nitrite (Model 5). Curves are model predictions;\nthe Griess dose-response will "
         "calibrate IC$_{50}^{NO}$ and n$_{app}$. LPS-only p65 = 0.85 as in the wiki NO figure, scaled by π(ψ)/π(0).", fontsize=7.4, color="#555555", va="top")
save(fig, "G06_free_NO_vs_nitrite")
for o in out: print(o)
