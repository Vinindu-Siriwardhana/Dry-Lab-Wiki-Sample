"""G06 -- predicted free NO and accumulated nitrite over 24 h at several V14 doses.
The caption lists the receptor, p65, iNOS, free-NO and nitrite equations."""
import numpy as np
from common import *

KD = KD_UM                                  # uM, V14-MD2 proxy from params.py
t = np.linspace(0, 24 * 3600, 4000)
N_cell, q_max = 1e6, P.Q_CHRONIC           # illustrative cell-count assumption
doses = [(0, S.C_DERIVED), (25, "#4F8FC4"), (round(TGT_UM), S.C_V14)]
fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.2, 4.0))
out = []
for C, col in doses:
    p65 = 0.85 * m.p65_scaled(C / KD, P.A_LPS, P.GAMMA, P.HILL_H) \
        / m.p65_scaled(0.0, P.A_LPS, P.GAMMA, P.HILL_H)
    R, NO, NO2 = m.inos_response(t, p65, N_cell, q_max, K_iNOS_rel=P.K_INOS_REL,
                                 p=P.P_INOS, k_turn=P.K_TURN, k_scav=P.K_SCAV,
                                 phi=P.PHI_NO2)
    lab = f"{C} µM V14" + ("  (LPS only)" if C == 0 else "  (target)" if C == round(TGT_UM) else "")
    ax.plot(t / 3600, NO / P.UM * 1e3, color=col, ls="-", label=lab)
    bx.plot(t / 3600, NO2 / P.UM, color=col, label=lab)
    out.append((C, p65, NO[-1] / P.UM * 1e3, NO2[-1] / P.UM))
for z in (ax, bx):
    z.set_xlim(0, 24); z.set_xticks([0, 6, 12, 18, 24]); z.set_xlabel("simulation time  (h)")
    z.set_ylim(bottom=0)
ax.set_ylabel("free NO concentration in assay well (nM)")
bx.set_ylabel("accumulated nitrite  (µM)")
ax.set_title("(a)  Free NO  ($[NO] \\approx R/k_{scav}$)", loc="left", fontsize=10)
ax.legend(loc="lower right", fontsize=7.4, framealpha=0.94)
drop = 1 - out[2][3] / out[0][3]
bx.set_title("(b)  Accumulated nitrite", loc="left", fontsize=10)
bx.legend(loc="upper left", fontsize=7.8)
r24 = out[0][3] / (out[0][2] / 1e3)
caption(fig,
         f"At 24 h, accumulated nitrite is about {r24:,.0f} times the free NO level shown in panel (a). "
         r"Equations: $\psi=C_V/K_{D,P}$; $\pi(\psi)=(a\gamma)^h/[(a\gamma)^h+(1+a+\psi)^h]$; "
         r"$p65_{rel}=0.85\,\pi(\psi)/\pi(0)$. "
         r"$dR/dt=k_{turn}[Nq_{max}p65_{rel}^{p}/(K_{iNOS}^{p}+p65_{rel}^{p})-R]$; "
         r"$[NO]\approx R/k_{scav}$; $d[NO_2^-]/dt=\phi R$. "
         r"Simulation assumptions: $N=10^6$ cells, 24 h; $a=[LPS]/K_{D,L}$.",
         x=0.07, y=-0.03, fontsize=7.2, color="#555555")
save(fig, "G06_free_NO_vs_nitrite")
for o in out: print(o)
