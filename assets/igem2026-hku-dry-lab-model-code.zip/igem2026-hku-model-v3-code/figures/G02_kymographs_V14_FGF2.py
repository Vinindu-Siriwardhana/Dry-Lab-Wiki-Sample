"""G02 -- concentration kymographs, gel + tissue, V14 and FGF2-G3 (two-domain solver).
Current design gel (params.L_GEL), R_V = 1; each arm starts from its mobile
fraction f_rel of the loaded dose, so colours are % of the TOTAL loading.
FGF2-G3 tissue diffusivity is scaled from V14 by the free-solution ratio (assumption)."""
import numpy as np
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from matplotlib.patches import Rectangle
import matplotlib.patheffects as pe
from common import *
from twodomain import TwoDomain, DAY

L_GEL = P.L_GEL
DISPLAY_DAYS = 60
X_MAX_DISPLAY = P.L_TIS * 10  # mm; end the display at the tissue solver boundary


def kymo(D0, a_nm, D_tis, k_prot, k_deg, f_rel):
    Dg = m.D_eff(D0, a_nm, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
    td = TwoDomain(D_gel=Dg, D_tis=D_tis, L_gel=L_GEL, L_tis=P.L_TIS,
                   nx_gel=NX_GEL, nx_tis=200, eps_gel=P.EPS_GEL, eps_tis=P.EPS_TIS,
                   K_p=P.K_P, k_prot=k_prot, k_deg_gel=k_deg, R_V=1.0)
    t_end = DISPLAY_DAYS * DAY
    res = td.run(f_rel, t_end=t_end, segments=segs(t_end))
    xg = -td.xg[::-1] * 10                         # gel drawn above the surface
    xt = np.concatenate([[0.0], -td.xt[1:]]) * 10  # tissue, mm
    C = np.concatenate([res["C_gel"][:, ::-1][:, :-1], res["C_tis"]], axis=1)
    x = np.concatenate([xg[:-1], xt])
    tq = np.logspace(1, np.log10(t_end), 500)
    Cq = np.array([np.interp(tq, res["t"], C[:, j]) for j in range(C.shape[1])]).T
    return x, tq / 3600, np.clip(Cq, 1e-4, None)


cmaps = {
    "V14": LinearSegmentedColormap.from_list(
        "v14", ["#FFFFFF", "#DCEAF6", "#9CC6E4", "#4F95CC", "#1F63A8", "#0B3266"]),
    "FGF2-G3": LinearSegmentedColormap.from_list(
        "fgf", ["#FFFFFF", "#FBE3D6", "#F4A582", "#D6604D", "#A51C30", "#5E0A1A"]),
}
arms = [("V14", P.D0_V14, P.A_V14_NM, P.D_TIS_V14, P.K_PROT_V14, P.K_DEG_GEL, P.F_REL_V14, S.C_V14),
        ("FGF2-G3", P.D0_FGF, P.A_FGF_NM, P.D_TIS_FGF, P.K_PROT_FGF, P.K_DEG_GEL_F, P.F_REL_FGF, S.C_FGF)]
norm = LogNorm(1e-3, 1)
target = P.C_TARGET_V14 / P.C_LOAD_V14          # as a fraction of the total V14 loading
target_F = P.EC50_F / P.C_LOAD_FGF_NGML         # FGF2-G3 EC50 as a fraction of its loading
halo = [pe.withStroke(linewidth=2.6, foreground="white")]

fig, axes = plt.subplots(1, 2, figsize=(11.2, 6.6), sharey=True)
fig.subplots_adjust(left=0.085, right=0.975, top=0.765, bottom=0.30, wspace=0.15)
stats = {}
for ax, (name, D0, a, Dt, kp, kg, fr, col) in zip(axes, arms):
    x, t, C = kymo(D0, a, Dt, kp, kg, fr)
    pc = ax.pcolormesh(x, t, C, norm=norm, cmap="viridis", shading="gouraud",
                       rasterized=True)
    ax.contour(x, t, C, levels=[0.01, 0.1, 0.5], colors=["white"],
               linewidths=0.7, alpha=0.6)
    ax.axvline(0, color="white", lw=1.4, ls="--", zorder=3)

    # Put the spatial-domain labels above the heatmap instead of on top of data.
    gel_fraction = L_GEL / (L_GEL + X_MAX_DISPLAY / 10)
    model_end_fraction = (L_GEL + P.L_TIS) / (L_GEL + X_MAX_DISPLAY / 10)
    ax.text(gel_fraction / 2, 1.025, "ALGINATE PATCH", transform=ax.transAxes,
            ha="center", va="bottom", fontsize=7.2, color="#536273", weight="bold",
            clip_on=False)
    ax.text((gel_fraction + model_end_fraction) / 2, 1.025, "WOUND TISSUE", transform=ax.transAxes,
            ha="center", va="bottom", fontsize=7.2, color="#536273", weight="bold",
            clip_on=False)
    ax.plot([0.02, gel_fraction - 0.018], [1.009, 1.009], transform=ax.transAxes,
            color="#CBD2D9", lw=0.8, clip_on=False)
    ax.plot([gel_fraction + 0.018, model_end_fraction - 0.018], [1.009, 1.009], transform=ax.transAxes,
            color="#CBD2D9", lw=0.8, clip_on=False)
    if name == "V14":
        ct = ax.contour(x, t, C, levels=[target], colors=[S.C_THRESH], linewidths=2.2)
        ct.set(path_effects=[pe.withStroke(linewidth=4, foreground="white")])
        above = C >= target
        tis = x >= 0
        deep = x[tis][above[:, tis].any(axis=0)].max()
        surf_h = t[above[:, np.argmin(np.abs(x))]].max() if above[:, np.argmin(np.abs(x))].any() else 0
        stats.update(deep=deep, surf_h=surf_h)
        threshold_text = f"TARGET  {TGT_LABEL}"
    else:
        ct = ax.contour(x, t, C, levels=[target_F], colors=[S.C_THRESH], linewidths=1.35)
        ct.set(path_effects=[pe.withStroke(linewidth=2.6, foreground="white")])
        tis = x >= 0
        aboveF = C[:, tis] >= target_F
        i0 = np.argmin(np.abs(x[tis]))
        stats.update(surf_hF=t[aboveF[:, i0]].max() if aboveF[:, i0].any() else 0)
        threshold_text = f"EC$_{{50}}$  {P.EC50_F:g} ng/mL"

    ax.set_yscale("log")
    ax.set_ylim(t[0], t[-1]); ax.set_xlim(x[0], X_MAX_DISPLAY)
    ax.set_yticks([0.01, 0.1, 1, 6, 24, 72, 168, 336, 720, 1440],
                  ["36 s", "6 min", "1 h", "6 h", "1 d", "3 d", "7 d", "14 d", "30 d", "60 d"])
    ax.set_xticks(np.arange(-L_GEL * 10, X_MAX_DISPLAY + 0.01, 0.5))
    ax.set_xlabel("distance from wound surface (mm)", labelpad=8)
    ax.set_title(name, loc="left", color=col, fontsize=12.5, pad=29)
    ax.text(0.99, 1.115, threshold_text, transform=ax.transAxes, ha="right", va="bottom",
            fontsize=8.0, color=S.C_THRESH, weight="bold", clip_on=False)
    ax.grid(False)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

axes[0].set_ylabel("time after patch application", labelpad=9)

# A single bar makes the matching logarithmic concentration scale explicit.
cax = fig.add_axes([0.22, 0.205, 0.56, 0.022])
cb = fig.colorbar(pc, cax=cax, orientation="horizontal")
cb.set_ticks([1e-3, 1e-2, 1e-1, 1], labels=["0.1", "1", "10", "100"])
cb.set_label("free concentration (% of total loading)", fontsize=8.0, labelpad=5)
cb.outline.set_linewidth(0.45)

fig.text(0.5, 0.965, f"TWO-DOMAIN TRANSPORT  ·  {GEL_LABEL} CALCIUM ALGINATE",
         ha="center", va="top", fontsize=8.1, color="#64717D", weight="bold")
fig.text(0.5, 0.925, "V14 reaches deeper; FGF2-G3 persists longer",
         ha="center", va="top", fontsize=15.2, color="#202A33", weight="bold")
fig.text(0.5, 0.882,
         f"V14: above {TGT_LABEL} for ~{stats['surf_h']:.0f} h at the tissue surface (point value), reaching {stats['deep']:.1f} mm  •  "
         f"FGF2-G3: above EC$_{{50}}$ for ~{stats['surf_hF'] / 24:.0f} d",
         ha="center", va="top", fontsize=9.0, color="#536273")
caption(fig,
         f"Two-domain solver, {DESIGN_NOTE}; R$_V$ = 1, k$_{{prot}}$ = {P.K_PROT_V14:.2e} (V14) / "
         f"{P.K_PROT_FGF:.2e} s$^{{-1}}$ (FGF2-G3) in tissue and the same rates in the gel,\n"
         f"tissue domain ends at the systemic sink at {P.L_TIS*10:.1f} mm. "
         f"Thin white lines: 1 %, 10 % and 50 % of "
         "the total loading (outer to inner); the immobile 1 - f$_{rel}$ is not drawn.\nOrange contours: V14 target "
         f"({TGT_LABEL} = {100 * target:.1f} % of {LOAD_UM:.0f} µM) and FGF2-G3 EC$_{{50}}$ ({100 * target_F:.2f} % of "
         f"{P.C_LOAD_FGF_NGML:g} ng/mL).\n"
         "FGF2-G3 is run with the linear tissue equation: heparan-sulfate retardation R$_F$ and the FGFR "
         "uptake sink are omitted, so its penetration is an upper bound.",
         x=0.07, y=0.135, fontsize=7.35, color="#65717C")
save(fig, "G02_kymographs_V14_FGF2")
