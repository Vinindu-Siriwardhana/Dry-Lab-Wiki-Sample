"""G07 -- dressing-change interval at the 145 uM target (tex sec:envelope method).
(a) one patch (params.L_GEL, loaded with f_rel x C_LOAD_V14): depth-averaged free V14 over the
    top delta, hours above target.
(b) repeat dosing through the effect compartment ds/dt = k_e0 (u - s).  The treated state needs
    BOTH drugs: u = 1 while the latest patch holds tissue above the V14 target AND tissue
    FGF2-G3 is at or above EC50_F.  One patch holds FGF2-G3 above EC50 far longer than any
    workable change interval, so after its onset the FGF arm is continuously satisfied and
    V14 sets the duty cycle.  r_p, d interpolate between the chronic and therapeutic rates;
    front tracked at the pinned threshold (as wiki fig10)."""
import numpy as np
from common import *
from twodomain import TwoDomain, UM, DAY

Dg = m.D_eff(P.D0_V14, P.A_V14_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
TGT = P.C_TARGET_V14


def patch(L_tis=P.L_TIS, D_t=P.D_TIS_V14):
    td = TwoDomain(D_gel=Dg, D_tis=D_t, L_gel=P.L_GEL, L_tis=L_tis, nx_gel=NX_GEL, nx_tis=200,
                   eps_gel=P.EPS_GEL, eps_tis=P.EPS_TIS, K_p=P.K_P, k_prot=P.K_PROT_V14,
                   k_deg_gel=P.K_DEG_GEL, R_V=1.0)
    res = td.run(FREE_V14, t_end=2 * DAY, segments=segs(2 * DAY))
    avg = td.depth_average(res, P.DELTA)
    h, _ = td.days_above(res, P.DELTA, TGT)
    return res["t"] / 3600, avg / UM, h * 24


t0, a0, h0 = patch()
_, aFa, hFa = patch(P.L_TIS_RANGE[0], P.D_TIS_V14_HI)   # fastest drain
_, aS, hS = patch(P.L_TIS_RANGE[1], P.D_TIS_V14_LO)     # slowest drain
hF, peakF, onsetF = fgf_cover()
THR = 0.5 * P.K_CARRY * (1 - P.D_PULSE / P.R_PULSE)


def closure_time(interval_h, R_w_cm, cov_h=h0, t_end_days=120, dt=60.0):
    t = np.arange(0.0, t_end_days * DAY + dt, dt)
    # treated state needs V14 above target AND FGF2-G3 at or above EC50
    u = (((t / 3600.0) % interval_h) < cov_h) & (t >= onsetF * 3600.0)
    s = np.zeros_like(t); a = np.exp(-dt * P.KE0)
    for i in range(1, len(t)):
        s[i] = u[i - 1] + (s[i - 1] - u[i - 1]) * a
    rp = lambda tt: P.R_CHRONIC + (P.R_PULSE - P.R_CHRONIC) * s[min(int(tt / dt), len(s) - 1)]
    dd = lambda tt: P.D_CHRONIC + (P.D_PULSE - P.D_CHRONIC) * s[min(int(tt / dt), len(s) - 1)]
    sol = m.FisherKPP(P.D_N, K=P.K_CARRY, R_inf=R_w_cm * 2.2, nr=500)
    res = sol.run(R_w_cm, rp, dd, t_end=t_end_days * DAY, record_every=40,
                  fixed_threshold=THR, w=P.W_SMOOTH)
    return res["t_c"] / DAY


def max_interval(R_w_cm, lo, hi=40.0, tol=0.2):
    while hi - lo > tol:
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if np.isfinite(closure_time(mid, R_w_cm)) else (lo, mid)
    return lo


fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.6, 4.3), gridspec_kw=dict(width_ratios=[1, 1.15]))
ax.fill_between(t0, np.minimum(aFa, aS), np.maximum(aFa, aS), color=S.C_V14_L, alpha=0.35, lw=0,
                label=f"range across tissue cases: {min(hFa, hS):.1f}–{max(hFa, hS):.1f} h above target")
ax.plot(t0, a0, color=S.C_V14, lw=2.2, label=f"central tissue case: {h0:.1f} h above target")
ax.axvspan(0, min(hF, 24), color=S.C_FGF_L, alpha=0.18, lw=0, zorder=0,
           label=f"FGF2-G3 above its target ({hF/24:.1f} d)")
ax.axhline(TGT / UM, color=S.C_THRESH, ls=":", lw=1.6, label=f"{TGT_LABEL} target")
ax.set_xlim(0, 24); ax.set_ylim(bottom=0); ax.set_xticks([0, 4, 8, 12, 16, 20, 24])
ax.set_xlabel("hours after applying one patch")
ax.set_ylabel(f"free V14 in top {P.DELTA*1e4:.0f} µm of tissue (µM)")
ax.set_title("(a)  V14 concentration after one patch", loc="left", fontsize=10)
ax.legend(loc="upper right", fontsize=7.8)

intervals = np.unique(np.round(np.r_[h0, np.linspace(8, 32, 9)], 2))
summary = {}
for R_mm, col in ((1.0, S.C_V14_L), (2.0, S.C_V14), (3.0, "#0B3C5D"),
                  (4.0, S.C_GOOD), (5.0, S.C_BAD)):
    tc = np.array([closure_time(h, R_mm / 10) for h in intervals])
    summary[R_mm] = tc
    fin = np.isfinite(tc)
    bx.plot(intervals[fin], tc[fin], "o-", color=col, ms=5, label=f"wound radius = {R_mm:g} mm")
    bx.plot(intervals[~fin], np.full((~fin).sum(), 118), "x", color=col, ms=7)
last_ok = intervals[np.isfinite(summary[2.0])].max()
hmax = max_interval(0.2, last_ok)
bx.axvline(hmax, color=S.C_DERIVED, ls="--", lw=1.2)
bx.text(hmax + 0.15, 62, f"2 mm wound:\nlongest workable\ninterval = {hmax:.1f} h", fontsize=8.4,
        color=S.C_DERIVED, weight="bold")
bx.text(0.02, 0.97, "× = wound still open after 120 days", transform=bx.transAxes, va="top",
        fontsize=7.8, color="#777777")
bx.set_xlim(intervals.min() - 1, intervals.max() + 1.5); bx.set_ylim(0, 125)
bx.set_xlabel("time between patch changes (hours)")
bx.set_ylabel("predicted time to wound closure (days)")
bx.set_title("(b)  Change schedule and predicted closure", loc="left", fontsize=10)
bx.legend(loc="upper left", bbox_to_anchor=(0.0, 0.9), fontsize=8)
caption(fig,
        f"Predictions for one {GEL_LABEL} alginate patch (V14 {P.C_LOAD_V14 * P.MW_V14 * 1e3:g} mg/mL; "
        f"FGF2-G3 {P.C_LOAD_FGF_NGML:g} ng/mL). The blue band compares faster and slower tissue drainage; it is a "
        f"scenario range, not a confidence interval. Panel (b) uses the central tissue case and assumes treatment requires "
        f"both drugs to stay above their targets. Tissue response rates are uncertain model assumptions. "
        f"The {TGT_LABEL} V14 target comes from the 17 Oct positive-gate result as an uncalibrated proxy.",
        fontsize=7.4, color="#555555")
save(fig, "G07_time_above_target_vs_dressing_interval")
print(f"coverage {h0:.2f} h (band {min(hFa,hS):.2f}-{max(hFa,hS):.2f}); max interval {hmax:.2f} h")
print(f"FGF2-G3: {hF:.1f} h above EC50 ({hF/24:.2f} d), peak {peakF:.2f} ng/mL, onset {onsetF:.2f} h")
for R, tc in summary.items():
    print(R, " ".join(f"{h:.1f}h:{t:.1f}d" for h, t in zip(intervals, tc)))
