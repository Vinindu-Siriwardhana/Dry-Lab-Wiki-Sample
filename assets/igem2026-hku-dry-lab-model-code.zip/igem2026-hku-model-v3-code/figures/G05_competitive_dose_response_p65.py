"""G05 -- competitive inhibition: model predictions for MD2 occupancy and nuclear p65."""
import csv, numpy as np
from common import *

KD = KD_UM                         # uM, calculated from wet-lab flow cytometry (params.py)
A_LIST = [(1.0, "#9DC3E2"), (5.0, "#4F8FC4"), (P.A_LPS, S.C_V14), (50.0, "#0B3C5D")]
C = np.logspace(-1, 4, 400)        # uM

fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.4, 4.3))
for a, col in A_LIST:
    r = m.suppression_ratio(C / KD, a)
    lw = 2.4 if a == P.A_LPS else 1.6
    lab = f"a = {a:.3g}" + ("  (1 µM FITC-LPS, this assay)" if a == P.A_LPS else "")
    ax.plot(C, r, color=col, lw=lw, label=lab)
    ic = KD * m.psi_50(a)
    ax.plot(ic, 0.5, "o", color=col, ms=6, mec="white", mew=1.2, zorder=5)
ax.axhline(0.5, color=S.C_GREY, lw=0.8, ls=":")
ax.text(0.12, 0.53, "IC$_{50}$ = K$_{D,P}$(1 + a)  (●)", fontsize=8, color="#555555")

# Tissue target concentration, expressed on the same concentration axis.
target_um = TGT_UM
ax.axvline(target_um, color="#555555", ls="--", lw=1.2, zorder=3)
ax.text(target_um * 1.3, 1.0, f"{target_um:.1f} \u00b5M tissue target", ha="left", va="bottom",
        fontsize=7.5, color="#444444", weight="bold")
ax.set_xscale("log"); ax.set_ylim(0, 1.18); ax.set_xlim(0.1, 1e4)
ax.set_xlabel("V14 concentration  (µM)")
ax.set_ylabel(r"LPS-bound MD2,  $\theta_{LPS}(C)\,/\,\theta_{LPS}(0)$")
ax.set_title("(a)  More endotoxin shifts the curve right", loc="left")
ax.legend(loc="lower left", fontsize=7.6)

th = np.linspace(0, 0.995, 400)
for a, col in A_LIST:
    psi = th * (1 + a) / (1 - th)
    lw = 2.4 if a == P.A_LPS else 1.6
    rel = m.p65_scaled(psi, a, P.GAMMA, P.HILL_H) / m.p65_scaled(0.0, a, P.GAMMA, P.HILL_H)
    bx.plot(th, rel, color=col, lw=lw,
            ls=S.LS_TIER4, label=f"a = {a:.3g}")
bx.set_xlim(0, 1); bx.set_ylim(0, 1.02)
bx.set_xlabel(r"V14 occupancy of MD2,  $\theta_{inhib}$")
bx.set_ylabel("nuclear p65, relative to LPS only")
bx.set_title("(b)  Nuclear p65 vs V14 occupancy (Model 4)", loc="left")
bx.legend(loc="lower left", fontsize=7.6)
bx.text(0.97, 0.93, "with the register γ = 0.1, aγ ≪ 1 + a,\nso the curves for all a coincide:\n"
        "p65 / p65$_{LPS}$ ≈ (1 − θ$_{inhib}$)$^h$", transform=bx.transAxes, ha="right", va="top",
        fontsize=8, color="#444444")
caption(fig,
         f"a = [LPS]/K$_{{D,L}}$. K$_{{D,P}}$ = {KD:.2f} \u00b5M, calculated from wet-lab flow cytometry. "
         f"The vertical marker shows the tissue target concentration: {target_um:.1f} \u00b5M V14. "
         "(a) plots the signalling-competent (LPS-bound) fraction, not total MD2 occupancy. Dashed curves in (b) use register values gamma = 0.1 and h = 2.",
         x=0.07, y=-0.03, fontsize=7.4, color="#555555")
save(fig, "G05_competitive_dose_response_p65")
print("tissue target uM:", target_um)
