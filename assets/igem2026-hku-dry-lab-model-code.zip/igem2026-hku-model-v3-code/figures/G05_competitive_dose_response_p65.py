"""G04 -- competitive inhibition: (a) active-receptor (LPS-bound MD2) occupancy ratio vs V14
for several endotoxin loads -- the rightward shift is the falsifiable signature of competition;
in-house flow point (14 Oct, 25 uM, a = 15.4) converted from gate frequency to occupancy.
(b) normalised nuclear p65 vs theta_inhib (Model 4; gamma and h are Tier-4)."""
import csv, numpy as np
from common import *

KD = KD_UM                         # uM, one-sided lower bound from the flow panel (params.py)
A_LIST = [(1.0, "#9DC3E2"), (5.0, "#4F8FC4"), (P.A_LPS, S.C_V14), (50.0, "#0B3C5D")]
C = np.logspace(-1, 4, 400)        # uM

fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.4, 4.3))
for a, col in A_LIST:
    r = m.suppression_ratio(C / KD, a)
    lw = 2.4 if a == P.A_LPS else 1.6
    lab = f"a = {a:.3g}" + ("  (1 µM FITC-LPS, this assay)" if a == P.A_LPS else "")
    ax.plot(C, r, color=col, lw=lw, label=lab)
    ic = KD * m.psi_50(a)
    ax.plot(ic, 0.5, "o", color=col, ms=6, mec="white", mew=1.2, zorder=5)
ax.axhline(0.5, color=S.C_GREY, lw=0.8, ls=":")
ax.text(0.12, 0.53, "IC$_{50}$ = K$_{D,P}$(1 + a)  (●)", fontsize=8, color="#555555")

# in-house point: mean gate drop and its 95 % CI (Student, trials 2-3)
f_lps = 14.34246987 / 100
drops = {"mean": 2.860701974, "lo": -0.840132733, "hi": 6.561536681}   # pp, LPS - V14
occ = {k: m.occupancy_from_gate(v / 14.34246987, P.SIGMA_FLOW_LOG, f_lps)
       for k, v in drops.items()}
y = 1 - occ["mean"]; ylo, yhi = 1 - occ["hi"], 1 - occ["lo"]
ax.errorbar(25, y, yerr=[[y - ylo], [yhi - y]], fmt="D", color=S.C_DERIVED, ms=7,
            mec="white", capsize=3, zorder=6, label=f"in house, 25 µM V14 (95 % CI {ylo:.2f}–{yhi:.2f})")
ax.set_xscale("log"); ax.set_ylim(0, 1.08); ax.set_xlim(0.1, 1e4)
ax.set_xlabel("V14 concentration  (µM)")
ax.set_ylabel(r"LPS-bound MD2,  $\theta_{LPS}(C)\,/\,\theta_{LPS}(0)$")
ax.set_title("(a)  More endotoxin shifts the curve right", loc="left")
ax.legend(loc="lower left", fontsize=7.6)

th = np.linspace(0, 0.995, 400)
for a, col in A_LIST:
    psi = th * (1 + a) / (1 - th)
    lw = 2.4 if a == P.A_LPS else 1.6
    rel = m.p65_scaled(psi, a, P.GAMMA, P.HILL_H) / m.p65_scaled(0.0, a, P.GAMMA, P.HILL_H)
    bx.plot(th, rel, color=col, lw=lw,
            ls=S.LS_TIER4, label=f"a = {a:.3g}")
bx.set_xlim(0, 1); bx.set_ylim(0, 1.02)
bx.set_xlabel(r"V14 occupancy of MD2,  $\theta_{inhib}$")
bx.set_ylabel("nuclear p65, relative to LPS only")
bx.set_title("(b)  Nuclear p65 vs V14 occupancy (Model 4)", loc="left")
bx.legend(loc="lower left", fontsize=7.6)
bx.text(0.97, 0.93, "with the register γ = 0.1, aγ ≪ 1 + a,\nso the curves for all a coincide:\n"
        "p65 / p65$_{LPS}$ ≈ (1 − θ$_{inhib}$)$^h$", transform=bx.transAxes, ha="right", va="top",
        fontsize=8, color="#444444")
fig.text(0.07, -0.03,
         f"a = [LPS]/K$_{{D,L}}$. K$_{{D,P}}$ = {KD} µM is the one-sided estimate from the 14 Oct flow panel. "
         f"The in-house point converts the positive-gate "
         f"drop to occupancy\nwith a log-normal per-cell model (σ = {P.SIGMA_FLOW_LOG}; to be refined from the FCS files). "
         "(a) plots the signalling-competent (LPS-bound) fraction, not total MD2 occupancy. Dashed curves in (b) use the register priors (γ = 0.1, h = 2; Tier 4).",
         fontsize=7.4, color="#555555", va="top")
save(fig, "G05_competitive_dose_response_p65")
print("occupancy ratio at 25uM:", y, ylo, yhi)
