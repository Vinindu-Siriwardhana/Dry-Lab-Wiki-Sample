"""G04 -- Model 3: partition of the MD2 pool using the current K_D,P proxy."""
import numpy as np
from common import *

KD = KD_UM                                   # uM, calculated from positive-gate frequency in params.py
a = P.A_LPS
C = np.logspace(-1, np.log10(5000), 600)    # uM
psi = C / KD
lps = a / (1 + a + psi)
v14 = psi / (1 + a + psi)
free = 1 - lps - v14

RED = "#B2182B"
fig, ax = plt.subplots(figsize=(7.6, 4.8))
ax.stackplot(C, lps, v14, free, colors=[RED, S.C_V14, "#E4E4E4"], alpha=0.92,
             edgecolor="white", lw=1.0,
             labels=["LPS-bound MD2 (signalling-competent)", "V14-bound MD2 (blocked)", "free MD2"])
marks = [(TGT_UM, TGT_LABEL + "\ntarget", S.C_THRESH)]
for x, lab, col in marks:
    y = a / (1 + a + x / KD)
    ax.axvline(x, color=col, ls=":", lw=1.4)
    ax.plot(x, y, "o", color="white", mec=col, mew=2, ms=7, zorder=5)
    ax.text(x, 1.015, lab, ha="center", va="bottom", fontsize=8, color=col, weight="bold")
    ax.annotate(f"{y:.0%}", (x, y), textcoords="offset points", xytext=(6, 6),
                fontsize=8.4, color="white", weight="bold")

ax.text(0.15, 0.45, f"no V14: {a/(1+a):.0%} of MD2\nis LPS-bound", fontsize=9.2,
        color="white", weight="bold")
ax.set_xscale("log"); ax.set_xlim(0.1, 5000); ax.set_ylim(0, 1)
ax.set_xticks([0.1, 1, 10, 100, 1000], ["0.1", "1", "10", "100", "1000"])
ax.set_xlabel("V14 concentration at the receptor  (µM)")
ax.set_ylabel("fraction of MD2 pool")
ax.grid(False)
ax.set_title(f"Model 3: competitive occupancy of MD2  (1 µM LPS, a = {a:.1f})",
             fontsize=10.5, pad=34)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), ncol=3, fontsize=7.8)
caption(fig,
         "θ$_{LPS}$ = a/(1 + a + [V14]/K$_{D,P}$),  θ$_{V14}$ = ([V14]/K$_{D,P}$)/(1 + a + [V14]/K$_{D,P}$); "
         "a = [LPS]/K$_{D,L}$, 1 µM FITC-LPS, K$_{D,L}$ = 65 nM (Viriyakosol 2000).\n"
         f"Current calculated K$_{{D,P}}$ = {KD:.2f} µM, calculated from the 17 Oct wet-lab flow-cytometry result. "
         "% label = LPS-bound fraction at the target.",
         x=0.02, y=-0.08, fontsize=7.4, color="#555555")
save(fig, "G04_md2_occupancy")
for x, _, _ in marks:
    print(x, a / (1 + a + x / KD))
