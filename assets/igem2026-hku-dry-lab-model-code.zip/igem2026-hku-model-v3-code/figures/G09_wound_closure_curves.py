"""G08 -- Model 6 wound closure vs days: untreated chronic bed and therapeutic pulses of
several durations (radial Fisher-KPP, pinned front threshold, as fig09 of the V3 bundle).
Right panel: predicted time to closure per scenario."""
import numpy as np
from common import *
DAY = P.DAY
R_w = 0.2                                              # cm (2 mm)
THR = 0.5 * P.K_CARRY * (1 - P.D_PULSE / P.R_PULSE)

def pulse(T_days):
    T = T_days * DAY
    s = lambda t: 1.0 if t <= T else np.exp(-(t - T) / P.TAU_RELAX)
    return (lambda t: P.R_CHRONIC + (P.R_PULSE - P.R_CHRONIC) * s(t),
            lambda t: P.D_CHRONIC + (P.D_PULSE - P.D_CHRONIC) * s(t))

def run(T_days, t_end=90):
    rp, dd = pulse(T_days) if T_days else (P.R_CHRONIC, P.D_CHRONIC)
    sol = m.FisherKPP(P.D_N, K=P.K_CARRY, R_inf=R_w * 2.2, nr=700)
    res = sol.run(R_w, rp, dd, t_end=t_end * DAY, record_every=40,
                  fixed_threshold=THR, w=P.W_SMOOTH)
    rf = res["r_front"].copy()
    if res["closed"]:
        rf[np.argmax(rf <= 1e-9):] = 0.0               # model not run past closure
    return res["t"] / DAY, 1 - (np.clip(rf, 0, R_w) / R_w) ** 2, res

cases = [(0, "untreated chronic", S.C_GREY), (5, "5 d pulse", S.C_BAD),
         (10, "10 d pulse", "#C97BB0"), (14, "14 d pulse", S.C_V14_L), (20, "20 d pulse", S.C_V14)]
fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.4, 4.2), gridspec_kw=dict(width_ratios=[1.6, 1]))
tcs = []
for T, lab, col in cases:
    t, A, res = run(T)
    ax.plot(t, A * 100, color=col, ls=S.LS_TIER4, lw=2, label=lab)
    tc = res["t_c"] / DAY if res["closed"] else np.inf
    tcs.append((lab, tc, col))
    if np.isfinite(tc):
        ax.plot(tc, 100, "o", color=col, ms=7, mec="white", mew=1.2, zorder=5)
    if T:
        ax.axvline(T, color=col, lw=0.7, ls=":", alpha=0.6)
ax.set_xlim(0, 90); ax.set_ylim(-2, 105)
ax.set_xlabel("days after treatment start")
ax.set_ylabel("wound area closed  (%)")
ax.set_title("(a)  Closure depends on treatment duration", loc="left", fontsize=10)
ax.legend(loc="center right", fontsize=8, title="treatment", title_fontsize=8)

y = np.arange(len(tcs))[::-1]
for yy, (lab, tc, col) in zip(y, tcs):
    if np.isfinite(tc):
        bx.barh(yy, tc, color=col, height=0.55)
        bx.text(tc + 0.8, yy, f"{tc:.1f} d", va="center", fontsize=8.6, weight="bold", color="#333333")
    else:
        bx.text(0.3, yy, "not closed by day 90",
                va="center", fontsize=8.4, color=S.C_BAD, weight="bold")
bx.set_yticks(y, [c[0] for c in tcs]); bx.set_ylim(-0.6, len(tcs) - 0.4); bx.grid(axis="y", visible=False)
bx.set_xlim(0, 40); bx.set_xlabel("predicted days to closure endpoint")
bx.set_title("(b)  Time to closure", loc="left", fontsize=10)
caption(fig,
         f"Radial Fisher–KPP, R$_w$ = 2 mm. Chronic bed r = {P.R_CHRONIC*DAY:.2f}/d, d = {P.D_CHRONIC*DAY:.2f}/d "
         f"(r$_{{eff}}$ < 0); during the pulse r = {P.R_PULSE*DAY:.2f}/d, d = {P.D_PULSE*DAY:.2f}/d, relaxing with "
         f"τ = {P.TAU_RELAX/3600:g} h afterwards (tex §durability).\nClosure is the model's fibroblast front reaching the wound "
         "centre, not a validated estimate of complete skin healing. Dashed: all Model 6 rates are Tier-4 priors; ● = closure endpoint. Parameter uncertainty: G12.",
         x=0.07, y=-0.03, fontsize=7.4, color="#555555")
save(fig, "G09_wound_closure_curves")
for c in tcs: print(c[:2])
