"""Shared setup for the New Graphs figure scripts.

The model code lives one directory up (params.py is the single source of truth; it follows the
tex register, with the 145 uM target from the 14 Oct flow panel).  save() writes the PNG
next to this file and, if the wiki repo is present, PNG + SVG into its assets folder.
"""
import os, sys, shutil, time
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # project folder (for Wet Lab Data)
sys.path.insert(0, ROOT)   # bundle layout: model modules sit one level up
WIKI_ASSETS = os.path.join(ROOT, "_remote_check", "assets")
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import style as S, params as P, v3model as m
S.apply()

# Flow-derived numbers in uM, read from params.py so that no figure carries its
# own copy. Rounded only to cancel float noise from the mol/cm3 <-> uM round trip.
KD_UM = round(P.KD_P_LOWER / P.UM, 4)      # one-sided lower bound on K_D,P
TGT_UM = round(P.C_TARGET_V14 / P.UM, 4)   # efficacious tissue concentration
TGT_LABEL = f"{TGT_UM:g} µM"

# Patch design (params.py, 2026-10-16). Loadings are TOTAL; only f_rel of each is mobile.
GEL_LABEL = f"{P.L_GEL * 10:g} mm"                       # gel thickness
LOAD_UM = P.C_LOAD_V14 / P.UM                            # V14 total loading, uM
SOL_UM = P.C_SOLUBILITY / P.UM                           # solubility lower bound, uM
FREE_V14 = P.F_REL_V14 * P.C_LOAD_V14                    # mobile V14, mol/cm3 (R_V = 1)
FREE_FGF_NGML = P.F_REL_FGF * P.C_LOAD_FGF_NGML          # mobile FGF2-G3, ng/mL
NX_GEL = 150                                             # gel nodes: converged to < 0.1 h at 2.5 mm
DESIGN_NOTE = (f"{GEL_LABEL} 1 % Ca-alginate; V14 {P.C_LOAD_V14 * P.MW_V14 * 1e3:g} mg/mL "
               f"({LOAD_UM:.0f} µM, f$_{{rel}}$ = {P.F_REL_V14:g}), FGF2-G3 {P.C_LOAD_FGF_NGML:g} ng/mL "
               f"(f$_{{rel}}$ = {P.F_REL_FGF:g})")


def fgf_cover(L_gel=None, t_end_days=21):
    """Hours the top-delta tissue average of FGF2-G3 stays >= EC50_F after one patch.
    Linear tissue equation (no heparan-sulfate retardation or FGFR uptake), so an upper bound.
    Solved in ng/mL so the EC50 threshold can be applied directly.
    Returns (hours above EC50, peak ng/mL, hours until EC50 is first reached)."""
    from twodomain import TwoDomain
    Df = m.D_eff(P.D0_FGF, P.A_FGF_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
    td = TwoDomain(D_gel=Df, D_tis=P.D_TIS_FGF, L_gel=L_gel or P.L_GEL, L_tis=P.L_TIS,
                   nx_gel=NX_GEL, nx_tis=200, eps_gel=P.EPS_GEL, eps_tis=P.EPS_TIS, K_p=P.K_P,
                   k_prot=P.K_PROT_FGF, k_deg_gel=P.K_DEG_GEL_F, R_V=1.0)
    T = t_end_days * 86400.0
    res = td.run(FREE_FGF_NGML, t_end=T, segments=segs(T))
    h, _ = td.days_above(res, P.DELTA, P.EC50_F)
    avg = td.depth_average(res, P.DELTA)
    hit = avg >= P.EC50_F
    onset = res["t"][hit.argmax()] / 3600 if hit.any() else float("inf")
    return h * 24, avg.max(), onset


def segs(t_end):
    """Time steps for TwoDomain.run, converged for the hours-above-target metric
    (0.5 s and 5 s through the release transient, 30 s to ~1 d, then 300 s)."""
    import math
    used = 0.5 * 120 + 5 * 108 + 30 * 2800
    return [(0.5, 120), (5, 108), (30, 2800), (300, max(1, math.ceil((t_end - used) / 300)))]


def _copy(src, dst):
    for _ in range(20):
        try:
            shutil.copyfile(src, dst); return
        except OSError:
            time.sleep(0.5)
    raise OSError("could not write " + dst)


def save(fig, name):
    png = os.path.join(HERE, name + ".png")
    fig.savefig(png, dpi=200)
    if os.path.isdir(WIKI_ASSETS):
        svg = os.path.join(WIKI_ASSETS, name + ".svg")
        fig.savefig(svg)
        _copy(png, os.path.join(WIKI_ASSETS, name + ".png"))
    plt.close(fig)
    print("  wrote", name)
