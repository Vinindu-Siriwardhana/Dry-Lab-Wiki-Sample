"""G03 -- (a) model cumulative release into a perfect sink (Crank series), 50 % and 95 % marked;
(b) updated in-house BCA FGF2-G3 release supernatants, blank-subtracted and expressed relative
to the positive control, beside the fitted Crank curve. The fit assumes the model's 2.5 mm gel
because the experimental gel thickness was not recorded."""
import numpy as np, openpyxl
from common import *

Dv = m.D_eff(P.D0_V14, P.A_V14_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
Df = m.D_eff(P.D0_FGF, P.A_FGF_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)

ws = openpyxl.load_workbook(os.path.join(ROOT, "Wet Lab Data", "BCA Updated.xlsx"),
                            data_only=True).active
def cells(r0, letter):
    return np.array([ws[f"{letter}{r}"].value for r in range(r0, r0 + 3)
                     if ws[f"{letter}{r}"].value is not None], float)
times = {"D": 60, "E": 90, "F": 120}

# FGF2-G3 released fraction: least-squares fit of f_rel x Crank(t; D_eff, L_GEL) to the
# 30-min read, gel-blank subtracted (n = 3 wells; the updated BCA has no 60-min read).
blank = cells(3, "B").mean(); pos = cells(3, "C").mean() - blank
tf = np.concatenate([np.full(len(cells(3, k)), tm) for k, tm in times.items()]) * 60.0
yf = np.concatenate([(cells(3, k) - blank) / pos for k in times])
gf = m.crank_cumulative(tf, Df, P.L_GEL)
F_FIT = gf @ yf / (gf @ gf)
F_FIT_SE = np.sqrt(np.sum((yf - F_FIT * gf) ** 2) / (len(yf) - 1) / (gf @ gf))

fig, (ax, bx) = plt.subplots(1, 2, figsize=(10.4, 4.2),
                             gridspec_kw=dict(width_ratios=[1.45, 1]))
t = np.logspace(0, np.log10(3 * 1440), 600)        # minutes
rows = []
# Plotted as a fraction of the TOTAL loaded dose, so each curve levels off at its
# released fraction f_rel and panel (b), which is also normalised to the total, shares the scale.
ax.axvspan(60, 120, color="#BBBBBB", alpha=0.22, lw=0, zorder=0)
ax.text(85, 0.59, "(b)", ha="center", va="top", fontsize=7.8, color="#666666", weight="bold")
for name, D, col, fr in (("V14", Dv, S.C_V14, P.F_REL_V14),
                         ("FGF2-G3", Df, S.C_FGF, P.F_REL_FGF)):
    L = P.L_GEL
    f = fr * m.crank_cumulative(t * 60, D, L)
    ax.plot(t, f, color=col, lw=2.2, label=f"{name}, {L*10:g} mm gel  (f$_{{rel}}$ = {fr:g})")
    ax.axhline(fr, color=col, lw=0.8, ls=":", alpha=0.7)
    ax.text(3 * 1440 * 0.95, fr + 0.016, f"f$_{{rel}}$ = {fr:g}", fontsize=7.6, color=col,
            weight="bold", ha="right")
    for frac, mk in ((0.5, "o"), (0.95, "s")):
        tt = m.release_time(frac, D, L) / 60
        ax.plot(tt, fr * frac, mk, color=col, ms=6, mec="white", mew=1.2, zorder=5)
        rows.append((name, L, frac, tt))
ax.plot([], [], "o", color="#666666", ms=6, mec="white", label="50 % of the mobile dose")
ax.plot([], [], "s", color="#666666", ms=6, mec="white", label="95 % of the mobile dose")
ax.set_xscale("log"); ax.set_xlim(1, 3 * 1440); ax.set_ylim(0, 0.62)
ax.set_xticks([1, 10, 60, 240, 1440], ["1 min", "10 min", "1 h", "4 h", "1 d"])
ax.set_xlabel("time in release buffer")
ax.set_ylabel("cumulative fraction of the TOTAL loaded dose")
ax.set_title("(a)  Model 1: release into a perfect sink", loc="left")
ax.legend(loc="center left", fontsize=7.4, framealpha=0.92)

# ---- (b) BCA ---------------------------------------------------------------
r0 = 3
blank = cells(r0, "B").mean()
pos = cells(r0, "C").mean() - blank
for letter, tm in times.items():
    y = (cells(r0, letter) - blank) / pos
    bx.plot(np.full(len(y), tm), y, "o", color=S.C_FGF, alpha=0.45, ms=6,
            mec="none")
    bx.errorbar(tm, y.mean(), yerr=y.std(ddof=1), fmt="o", color=S.C_FGF,
                ms=8, mec="white", capsize=3, lw=1.3,
                label="BCA read at 30 min" if letter == "D" else None)
tb = np.linspace(40, 140, 100)
thick = P.L_GEL
bx.plot(tb, F_FIT * m.crank_cumulative(tb * 60, Df, thick), color=S.C_FGF_L, lw=2.2,
        label=f"model fit, {thick*10:g} mm gel: f$_{{rel}}$ = {F_FIT:.2f} ± {F_FIT_SE:.2f}\n(30-min read)")
mod60, mod120 = [F_FIT * m.crank_cumulative(np.array([x * 60.0]), Df, thick)[0]
                 for x in (60, 120)]
bx.axhline(0, color="#888888", lw=0.8)
bx.set_xlim(40, 140); bx.set_ylim(-0.08, 0.4)
bx.set_xticks([60, 90, 120])
bx.set_xlabel("sampling time  (min)")
bx.set_ylabel("BCA signal / positive control\n(blank-subtracted)")
bx.set_title("(b)  In-house FGF2-G3 release (updated BCA, 30-min read)", loc="left")
bx.legend(loc="upper center", fontsize=7.6, framealpha=0.92)
caption(fig,
         "(b) apparent fraction = (A − A$_{blank}$)/(A$_{positive}$ − A$_{blank}$), n = 3 wells per sampling time; "
         "assumes the positive control equals the full loaded dose, so the model is plotted as f$_{rel}$ × (fraction of mobile dose).\n"
         "Same material as the model (1 % Ca-alginate). Signals are near the BCA assay noise floor. The V14 supernatant was sampled once at an unrecorded time and is not plotted.\n"
         "\N{BLACK RIGHT-POINTING TRIANGLE} " f"Updated fit: f$_{{rel}}$ = {F_FIT:.3f} (residual-based SE {F_FIT_SE:.3f}, n = 9) is adopted as {P.F_REL_FGF:.2f} ± {P.F_REL_FGF_SE:.2f} in params.py; "
         f"the {P.L_GEL*10:g} mm design gel then gives {100*mod60:.0f}–{100*mod120:.0f} % of the loaded dose at 60–120 min. "
         "The signal remains at the assay noise floor, so pinning down either f$_{rel}$ or the release timescale needs "
         "the assay run to completion on a log grid from ≲ 1 min, with thickness and buffer volume recorded.",
         x=0.07, y=-0.03, fontsize=7.4, color="#555555")
save(fig, "G03_release_curves_and_BCA")
for r in rows: print(r)
