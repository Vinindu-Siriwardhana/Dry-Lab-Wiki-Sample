"""G01 -- peptide screening gates (suitability model, sequence-level modules B and C).
Sequence properties are Table 3 of igem_peptide_suitability_model.pdf.
Release half-time is recomputed from V3 transport (t_1/2,rel = 0.196 L^2 / D_eff)."""
import numpy as np
from matplotlib.patches import Rectangle
from common import *

pep = [  # name, sequence note, nCys, nTrp, nonpolar %, t_serum (h), binding evidence
    ("TAP1",    0, 0, 45.0, 0.6, "literature (phage display)"),
    ("TAP2",    2, 3, 61.1, 0.9, "literature-active (SPR)"),
    ("TAP3",    2, 3, 44.4, 1.3, "literature (phage display)"),
    ("MD2-I",   2, 0, 29.4, 0.7, "benchmark: blocks at 100 µM"),
    ("MD2-II",  1, 0, 35.3, 1.0, "inactive control (C95A)"),
    ("αTI-14 (V14)", 0, 0, 69.2, 6.1, "in house: −21.34 % positive-gate frequency at 25 µM\n(p = 0.0186, n = 4/group; flow, 17 Oct)"),
]
D = m.D_eff(P.D0_V14, P.A_V14_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
t_rel = {L: 0.196 * L**2 / D / 3600 for L in (P.L_GEL, 0.05)}   # h
tr = t_rel[P.L_GEL]               # current design gel (params.L_GEL)

rows = []
for name, nc, nw, npol, th, ev in pep:
    sBc = 1 - nc / (nc + 1)
    sB = sBc * np.exp(-0.5 * nw)
    sC = th / (th + tr)
    gB = nc <= 1
    gC = sC >= 0.5
    rows.append((name, nc, nw, sB, gB, th, sC, gC, gB and gC, ev))

cols = ["Cys\n(gate ≤ 1)", "Trp", "structural\n$s_B$", "serum $t_{1/2}$\n(h)",
        "stability\n$s_C$", "sequence\nverdict", "binding evidence (Module A)"]
widths = [1.0, 0.7, 1.0, 1.0, 1.0, 1.1, 3.3]
x0 = np.concatenate([[0], np.cumsum(widths)])
PASS, FAIL, NEUT = "#D9EED0", "#F6D5D5", "#F2F2F2"

fig, ax = plt.subplots(figsize=(10.2, 3.7))
ax.set_xlim(-1.7, x0[-1]); ax.set_ylim(len(rows) + 0.05, -1.0)
ax.axis("off")
for j, c in enumerate(cols):
    ax.text(x0[j] + widths[j] / 2, -0.55, c, ha="center", va="center",
            fontsize=8.6, weight="bold", color="#333333")
for i, (name, nc, nw, sB, gB, th, sC, gC, ok, ev) in enumerate(rows):
    hl = name.startswith("αTI")
    ax.text(-1.6, i + 0.5, name, ha="left", va="center", fontsize=9.2,
            weight="bold" if hl else "normal", color=S.C_V14 if hl else "#222222")
    cells = [(str(nc), PASS if gB else FAIL), (str(nw), NEUT),
             (f"{sB:.2f}", NEUT), (f"{th:.1f}", NEUT),
             (f"{sC:.2f}", PASS if gC else FAIL),
             ("✓ pass" if ok else "✗ fail", PASS if ok else FAIL), (ev, "white")]
    for j, (txt, fc) in enumerate(cells):
        ax.add_patch(Rectangle((x0[j] + 0.04, i + 0.06), widths[j] - 0.08, 0.88,
                               facecolor=fc, edgecolor="none"))
        ax.text(x0[j] + (0.1 if j == 6 else widths[j] / 2), i + 0.5, txt,
                ha="left" if j == 6 else "center", va="center",
                fontsize=7.6 if j == 6 else 9, color="#222222",
                weight="bold" if j == 5 else "normal")
    if hl:
        ax.add_patch(Rectangle((-1.68, i + 0.02), x0[-1] + 1.66, 0.96,
                               fill=False, edgecolor=S.C_V14, lw=1.6))

removed = [r[0] for r in rows if not r[8]]
kept = [r[0] for r in rows if r[8]]
_and = lambda xs: " and ".join([", ".join(xs[:-1]), xs[-1]] if len(xs) > 2 else xs)
ax.set_title(f"Sequence gates remove {_and(removed)}; V14 has the longest predicted "
             f"half-life of the survivors ({_and(kept)})", fontsize=10.5, loc="left", x=-0.02)
caption(fig,
         f"$s_B$ = (1 − n$_{{Cys}}$/(n$_{{Cys}}$+1))·exp(−0.5 n$_{{Trp}}$);  "
         f"$s_C$ = t$_{{1/2}}$/(t$_{{1/2}}$ + t$_{{1/2,rel}}$) with V3 release half-time "
         f"t$_{{1/2,rel}}$ = {tr*60:.0f} min ({GEL_LABEL} alginate design gel; {t_rel[0.05]*60:.1f} min for the earlier 0.5 mm gel).\n"
         f"The {GEL_LABEL} gel releases slowly enough (t$_{{1/2,rel}}$ = {tr*60:.0f} min) that the stability gate now "
         f"BITES: it needs a serum t$_{{1/2}}$ ≥ {tr:.2f} h, which {_and([r[0] for r in rows if not r[7]])} fail.\n"
         "With the earlier 0.5 mm gel every candidate cleared it and only the structural gate (Cys, Trp) "
         "discriminated, so TAP1 survived; it passes that gate outright and now drops out on stability alone.\n"
         "Serum half-lives from the Cavaco regression (R² ≈ 0.76); wound-fluid half-lives are expected "
         "to be shorter. Green = gate passed, red = gate failed.",
         x=0.13, y=0.04, fontsize=7.6, color="#555555")
save(fig, "G01_peptide_screening")

