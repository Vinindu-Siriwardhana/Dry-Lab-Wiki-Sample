"""G09 -- Model 7 design space: V14 loading x gel thickness, colour = hours the top-delta tissue
average stays above the 145 uM target after ONE patch (two-domain solver, R_V = 1).
The x axis is the TOTAL loading; only f_rel of it is mobile, which the solve applies.
3 mg/mL is known to dissolve, so loadings beyond it are flagged as unverified, not infeasible."""
import numpy as np
from common import *
from twodomain import TwoDomain, UM, DAY

Dg = m.D_eff(P.D0_V14, P.A_V14_NM, P.XI_NM, P.EPS_GEL, P.A_FIBRE_NM)
loads = np.unique(np.r_[np.logspace(np.log10(200), np.log10(6000), 22), LOAD_UM])   # uM total
Ls = np.unique(np.r_[np.linspace(0.5, 4.0, 15), P.L_GEL * 10]) * 0.1                # cm
days = np.zeros((len(Ls), len(loads)))
for i, L in enumerate(Ls):
    td = TwoDomain(D_gel=Dg, D_tis=P.D_TIS_V14, L_gel=L, L_tis=P.L_TIS, nx_gel=NX_GEL,
                   nx_tis=200, eps_gel=P.EPS_GEL, eps_tis=P.EPS_TIS, K_p=P.K_P,
                   k_prot=P.K_PROT_V14, k_deg_gel=P.K_DEG_GEL, R_V=1.0)
    res = td.run(P.F_REL_V14, t_end=6 * DAY, segments=segs(6 * DAY))   # linear: scale by TOTAL loading
    avg = td.depth_average(res, P.DELTA)
    tt = res["t"]
    for j, c in enumerate(loads):
        above = avg * c * UM >= P.C_TARGET_V14
        days[i, j] = np.sum(np.diff(tt) * (above[1:] | above[:-1])) / 3600.0   # hours

fig, ax = plt.subplots(figsize=(7.4, 4.6))
lev = [0, 1, 2, 3, 4, 6, 8, 12, 16]
cf = ax.contourf(loads, Ls * 10, days, levels=lev, cmap="Blues", extend="max")
cs = ax.contour(loads, Ls * 10, days, levels=[2, 4, 8], colors=[S.C_DERIVED], linewidths=1.1)
ax.clabel(cs, fmt=lambda v: f"{v:g} h", fontsize=8)
ceil = SOL_UM
ax.axvspan(ceil, loads[-1], facecolor="none", edgecolor="#777777", hatch="///", lw=0)
ax.axvline(ceil, color=S.C_THRESH, lw=1.8)
ax.text(ceil * 1.06, Ls[-1] * 10 - 0.05, "beyond the demonstrated\nloading (3 mg/mL):\nsolubility unverified",
        fontsize=8.2, color="#444444", va="top", weight="bold",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.85, pad=2))
ax.plot(ceil, P.L_GEL * 10, "*", ms=15, color=S.C_THRESH, mec="white", zorder=6)
j = np.argmin(np.abs(loads - ceil)); i = np.argmin(np.abs(Ls - P.L_GEL))
ax.annotate(f"current design\n{GEL_LABEL}, {LOAD_UM:.0f} µM", (ceil, P.L_GEL * 10), textcoords="offset points",
            xytext=(-104, -34), fontsize=8.2, color=S.C_DERIVED, weight="bold",
            arrowprops=dict(arrowstyle="->", color=S.C_DERIVED, lw=1))
ax.set_xscale("log")
ax.set_xticks([200, 500, 1000, 2000, 5000], ["200", "500", "1000", "2000", "5000"])
ax.set_xlabel(f"total V14 loading in the gel  (µM;  f$_{{rel}}$ = {P.F_REL_V14:g} of it is mobile)")
ax.set_ylabel("gel thickness  (mm)")
cb = fig.colorbar(cf, ax=ax, pad=0.02); cb.set_label(f"hours above {TGT_LABEL} target (one patch)")
best = days[:, loads <= ceil].max()
ax.set_title("Model 7 design space: hours above target per patch",
             fontsize=10.5, loc="left")
fig.text(0.02, -0.02,
         f"Two-domain solver, 1 % Ca-alginate, R$_V$ = 1, k$_{{prot}}$ = k$_{{deg}}$ = {P.K_PROT_V14:.2e} s$^{{-1}}$ (Tier 4), systemic sink at {P.L_TIS*10:.1f} mm, "
         f"top-{P.DELTA*1e4:.0f} µm depth average. The solver is linear in loading, so each thickness is solved once and "
         "scaled; only f$_{rel}$ of the loading is mobile.\n"
         f"Current design ({GEL_LABEL}, {LOAD_UM:.0f} µM): {days[i, j]:.1f} h per patch; thicker gels extend this "
         f"(≈ {best:.1f} h at {Ls[-1]*10:g} mm). Continuous coverage is achieved with scheduled dressing changes (G07).",
         fontsize=7.4, color="#555555", va="top")
save(fig, "G10_design_feasibility_map")
print("current design days:", days[i, j], " best feasible:", best,
      " at L=", Ls[np.unravel_index(np.argmax(np.where(loads <= ceil, days, -1)), days.shape)[0]] * 10)
