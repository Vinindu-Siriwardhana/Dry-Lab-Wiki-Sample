"""G13 -- parameter provenance by module (params.PROVENANCE), every count readable."""
import numpy as np
from common import *

mods = list(P.PROVENANCE.keys())[::-1]
tiers = [("T1", "#1A5E2A", "T1  measured in house"), ("T2", "#4393C3", "T2  mechanistic correlation"),
         ("T3", "#F4A582", "T3  named literature analogue"), ("T4", "#B2182B", "T4  order-of-magnitude prior")]
fig, ax = plt.subplots(figsize=(8.4, 3.8))
y = np.arange(len(mods)); left = np.zeros(len(mods))
for key, col, lab in tiers:
    v = np.array([P.PROVENANCE[mm][key] for mm in mods])
    ax.barh(y, v, left=left, color=col, height=0.62, label=lab, edgecolor="white", lw=1.5)
    for i, (vv, ll) in enumerate(zip(v, left)):
        if vv:
            ax.text(ll + vv / 2, i, str(vv), ha="center", va="center", fontsize=8.6,
                    color="#222222" if key == "T3" else "white", weight="bold")
    left += v
for i, mm in enumerate(mods):
    u = P.PROVENANCE[mm]["unplanned"]
    ax.text(left[i] + 0.25, i, f"{u} of {int(left[i])} not yet scheduled for measurement",
            va="center", fontsize=8, color="#444444")
ax.set_yticks(y, mods); ax.grid(axis="y", visible=False)
ax.set_xlim(0, 18.5); ax.set_xticks(range(0, 13, 2)); ax.set_xlabel("number of parameters")
ax.set_title("Parameter provenance by model module", fontsize=10, loc="left")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=4, fontsize=7.8)
save(fig, "G13_parameter_provenance")
