"""Show the 17 Oct flow result and its model-based K_D,P implication.

Panel A shows the measured positive-gate frequencies for FITC-LPS and V14.
Panel B shows the V14 tissue concentration required for two modeled levels of
suppression over a range of K_D,P values, with the current 17 Oct proxy marked.
The K_D,P value assumes the positive-gate ratio equals relative LPS occupancy.
"""

import os
import sys

import numpy as np
from scipy import stats

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, "model"))
sys.path.insert(0, os.path.dirname(_HERE))

import style  # noqa: E402
import params as P  # noqa: E402
from v3model import dose_required  # noqa: E402
from common import save  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

style.apply()

# 17 Oct flow-cytometry result (mean +/- SD, n=4 per group).
L_LPS_UM = 1.0
KD_L_UM = 0.065
V14_DOSE_UM = 25.0
LPS_GATE_MEAN = 16.3070906979
LPS_GATE_SD = 2.0768884865
V14_GATE_MEAN = 12.8271153605
V14_GATE_SD = 0.6480258306
P_VALUE = 0.0186
N_GROUP = 4

KD_PROXY_UM = P.KD_P_PROXY / P.UM
TARGET_UM = P.C_TARGET_V14 / P.UM
A_LPS = L_LPS_UM / KD_L_UM
DROP_PCT = 100 * (1 - V14_GATE_MEAN / LPS_GATE_MEAN)
P_WELCH = stats.ttest_ind_from_stats(V14_GATE_MEAN, V14_GATE_SD, N_GROUP,
                                     LPS_GATE_MEAN, LPS_GATE_SD, N_GROUP,
                                     equal_var=False).pvalue


def panel_a(ax):
    colors = ["#78909C", style.C_V14]
    means = [LPS_GATE_MEAN, V14_GATE_MEAN]
    sds = [LPS_GATE_SD, V14_GATE_SD]
    labels = ["FITC-LPS", "FITC-LPS + V14\n(25 µM)"]
    x = np.arange(2)
    ax.bar(x, means, color=colors, width=0.58, alpha=0.9, zorder=2)
    ax.errorbar(x, means, yerr=sds, fmt="none", ecolor="#263238",
                elinewidth=1.4, capsize=4, capthick=1.4, zorder=3)
    for xi, yi in zip(x, means):
        ax.text(xi, yi + 0.72, f"{yi:.2f}%", ha="center", va="bottom",
                fontsize=9, fontweight="bold", color="#263238")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 23)
    ax.set_ylabel("Positive-gate frequency (%)")
    ax.set_title("A   17 Oct flow result", loc="left")
    ax.text(0.5, 0.96,
            f"{DROP_PCT:.2f}% lower with V14   ·   n = {N_GROUP}/group\n"
            f"Student p = {P_VALUE:g}   ·   Welch p = {P_WELCH:.3f}",
            transform=ax.transAxes, ha="center", va="top", fontsize=8.5,
            color="#37474F", bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.82, "pad": 2.5})
    ax.grid(axis="y", color="#D8DEE3", linewidth=0.7, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)


def panel_b(ax):
    kd = np.logspace(np.log10(0.3), np.log10(60), 400)
    for remaining_signal, label, color in [
        (0.5, r"$\theta_{LPS}$ = 0.5  (half of MD2 LPS-bound = target)", style.C_V14),
        (0.1, r"$\theta_{LPS}$ = 0.1", style.C_BAD),
    ]:
        required = np.array([
            dose_required(k, L_LPS_UM, KD_L_UM, 1.0, remaining_signal)
            for k in kd
        ])
        ax.plot(kd, required, color=color, lw=2.1, label=label)

    ax.axvline(KD_PROXY_UM, color=style.C_DERIVED, lw=1.7, ls="--", zorder=1)
    ax.scatter([KD_PROXY_UM], [TARGET_UM], s=38, color=style.C_DERIVED,
               edgecolor="white", linewidth=0.8, zorder=5)
    ax.annotate(f"17 Oct proxy: {KD_PROXY_UM:.2f} µM\nmodel target: {TARGET_UM:.1f} µM",
                xy=(KD_PROXY_UM, TARGET_UM), xytext=(12, -14),
                textcoords="offset points", fontsize=8, color=style.C_DERIVED,
                ha="left", va="top",
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.88, "pad": 2})
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(0.3, 60)
    ax.set_ylim(1, 1e5)
    ax.set_xlabel(r"$K_{D,P}$ proxy ($\mu$M)")
    ax.set_ylabel(r"required tissue V14 concentration ($\mu$M)")
    ax.set_title("B   Modeled delivery requirement", loc="left")
    ax.legend(frameon=False, loc="upper left", fontsize=8)
    ax.grid(axis="both", which="major", color="#D8DEE3", linewidth=0.7)
    ax.spines[["top", "right"]].set_visible(False)


def main():
    fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(11.8, 4.8),
                                    gridspec_kw={"width_ratios": [0.92, 1.2]})
    panel_a(ax_a)
    panel_b(ax_b)
    fig.text(0.5, -0.025,
             r"The $K_{D,P}$ value is an exploratory model-based estimate from the 17 Oct result; "
             r"it assumes the positive-gate ratio equals relative LPS occupancy." "\n"
             f"Lines are absolute LPS-bound fractions (no V14: {A_LPS / (1 + A_LPS):.2f}). "
             f"A 50 % relative drop is the IC$_{{50}}$ = K$_{{D,P}}$(1 + a) = {KD_PROXY_UM * (1 + A_LPS):.0f} µM, a different dose.",
             ha="center", va="top", fontsize=8, color="#666666", style="italic")
    fig.tight_layout(w_pad=2.0)
    save(fig, "WL_kdp_bound_25uM")
    print(f"  Current 17 Oct K_D,P proxy: {KD_PROXY_UM:.3f} µM")
    print(f"  Model-derived V14 tissue target: {TARGET_UM:.1f} µM")


if __name__ == "__main__":
    main()
