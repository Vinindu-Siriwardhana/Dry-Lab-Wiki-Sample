"""
WL_kdp_bound_25uM.py -- what the null flow-cytometry panel actually constrains.

The variant panel was run at [peptide] = 25 uM against [L] = 1 uM FITC-LPS, and the
FITC-H histograms (v5, v14 vs FITC-LPS, 2026-10-14) overlie the LPS control with no
resolvable shift. That is not a failed experiment: it is an upper bound on affinity.

Panel A  normalised MFI, Eq. (eq:mfi), against peptide dose, for a family of K_D,P.
         Any curve that drops below the detection band at 25 uM is EXCLUDED by the
         observation. The illustrative K_D,P = 1 uM scenario used in P6 is excluded
         by a wide margin.

Panel B  the tissue concentration the device would have to deliver, Eq. (eq:preq),
         as a function of K_D,P -- i.e. what the bound costs the delivery arm.

The bound is one-sided. These data are equally consistent with no specific binding
at all; K_D,P >= X is NOT an estimate of K_D,P.

    ratio(C) = theta_LPS(C)/theta_LPS(0) = (1 + a)/(1 + a + C/K_D,P)
    f = 1 - ratio   (fractional MFI drop)
    => IC50 >= C_V (1 - f)/f        -- independent of a, so free of K_D,L
       K_D,P >= IC50/(1 + a)        -- inherits K_D,L's Tier-3 uncertainty

HKU iGEM 2026 Dry Lab.
"""

import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
# ./model in the project tree; one level up in the distributed code bundle
sys.path.insert(0, os.path.join(_HERE, "model"))
sys.path.insert(0, os.path.dirname(_HERE))

import style                                    # noqa: E402
from v3model import dose_required, occupancy_from_gate  # noqa: E402

import matplotlib.pyplot as plt                 # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

style.apply()

# --- the measured scenario --------------------------------------------------
C_V = 25.0            # uM   peptide dose used in the panel      (wet lab, 14 Oct)
L_LPS = 1.0           # uM   FITC-LPS concentration              (wet lab, 14 Oct)
KD_L = 0.065          # uM   LPS-MD2 K_D = 65 nM                 T3, Viriyakosol 2000
A_LPS = L_LPS / KD_L  # = 15.38

# Smallest drop the panel could have resolved, in GATE-FREQUENCY units.
# Source: trials2_3_positive_gate_frequency_raw_data.csv, LPS-alone arm,
# n = 3, mean 14.3425 %, SD 1.7881 pp.
#
# Three defensible figures, all two-sided at df = 4 (t_crit = 2.776):
#   28.3 %  control SD for both arms (4.054 pp)  -> K_D,P >= 9.84, target 141 uM
#   27.8 %  as above with SD rounded to 1.76 pp  -> K_D,P >= 10.06, target 145 uM
#   25.8 %  actual pooled SD of both arms, which is what the 95 % CI
#           half-width in trials2_3_student_raw_p_comparisons.csv implies
#           (the v14 arm is tighter, SD 1.46 pp)  -> K_D,P >= 11.0, target 158 uM
#
# 27.8 % is held deliberately: the resulting 145 uM target is quoted throughout
# the model documents and the wiki, and the whole spread above (141-158 uM) is
# far inside the Tier-4 band carried by SIGMA_LOG alone (K_D,P 4.7-18.2 uM), so
# no conclusion in the model turns on the choice.  Recorded rather than silently
# rounded, because K_D,P is a ONE-SIDED bound and the target inherits that:
# quoting it to three significant figures would overstate what the panel knows.
F_DETECT_GATE = 0.278
F_LPS_GATE = 0.1434   # positive-gate frequency, LPS alone      (wet lab, 14 Oct)
F_BG_GATE  = 0.0043   # positive-gate frequency, viability-only (wet lab, 14 Oct)

# The panel reported GATE FREQUENCY, not MFI. The gate sits ~1.08 sigma above
# the population log-mean (calibrated from F_LPS_GATE), so the median cell is
# gate-negative and the readout AMPLIFIES occupancy changes roughly 2x. Feeding
# F_DETECT_GATE straight into the IC50 formula would assume the MFI mapping and
# bias K_D,P LOW by 2.5-4.6x. v3model.occupancy_from_gate does the conversion.
#
# SIGMA_LOG is the log-SD of per-cell FITC intensity. It is the controlling
# unknown and is NOT recoverable from means and SDs -- it needs the histogram or
# the FCS files. Until then the bound is a RANGE, not a number.
SIGMA_LOG = 0.7              # central assumption; typical flow CV
SIGMA_RANGE = (0.4, 1.4)     # plausible span -> K_D,P from 18.2 down to 4.7 uM

KD_P_ILLUSTRATIVE = 1.0   # the scenario P6 plots -- still excluded at every sigma

# Panel A is drawn in OCCUPANCY space (normalised MFI), so the detection band
# must be converted out of gate units before it is plotted there. Everything
# below this line is occupancy; everything above it is gate frequency.
F_DETECT_OCC = float(occupancy_from_gate(F_DETECT_GATE, SIGMA_LOG,
                                         F_LPS_GATE, F_BG_GATE))

# K_D,P family for panel A, light -> dark = tighter -> weaker binding.
# 10.08 is the current bound at SIGMA_LOG (highlighted by panel A). 3.92 was the
# bound before the gate/MFI conversion was applied; both kept for scale.
KD_FAMILY = [0.3, 1.0, 3.92, 10.08, 60.0]
RAMP = LinearSegmentedColormap.from_list("v14", [style.C_V14_L, "#0B3D62"])


def ratio(conc, kd_p, a=A_LPS):
    """Normalised MFI between the two controls -- Eq. (eq:mfi)."""
    return (1.0 + a) / (1.0 + a + conc / kd_p)


def kd_bound(f_gate, c_v=C_V, a=A_LPS, sigma=None):
    """
    (IC50, K_D,P) lower bounds implied by hiding at most a GATE-FREQUENCY drop
    of f_gate.  The gate drop is converted to an occupancy drop first; passing
    it through unconverted is the MFI assumption and biases K_D,P low.
    """
    f_occ = occupancy_from_gate(f_gate, SIGMA_LOG if sigma is None else sigma,
                                F_LPS_GATE, F_BG_GATE)
    ic50 = c_v * (1.0 - f_occ) / f_occ
    return ic50, ic50 / (1.0 + a)


def panel_a(ax):
    conc = np.logspace(-1, 3.4, 600)

    # band of outcomes indistinguishable from "no shift". Its label goes on the
    # RIGHT, where no curve enters the band, leaving the left half free for the
    # observation marker's own label.
    ax.axhspan(1.0 - F_DETECT_OCC, 1.035, color=style.C_GREY, alpha=0.38, zorder=0)
    ax.text(900, 1.0 - F_DETECT_OCC / 2,
            f"a shift smaller than {F_DETECT_OCC:.0%} is invisible on the overlay",
            fontsize=7.4, color="#5A5A5A", va="center", ha="center", zorder=5)

    _, kd_bnd = kd_bound(F_DETECT_GATE)
    # each curve is labelled at its own IC50 (where it crosses 0.5), which on a log
    # axis spreads the labels out automatically -- no right-edge pile-up.
    for i, kd in enumerate(KD_FAMILY):
        is_bound = abs(kd - kd_bnd) < 0.05
        excluded = ratio(C_V, kd) < 1.0 - F_DETECT_OCC - 5e-3
        col = style.C_BAD if is_bound else RAMP(i / (len(KD_FAMILY) - 1))
        ax.plot(conc, ratio(conc, kd), color=col,
                ls=(0, (5, 1.6)) if excluded else style.LS_CONSTRAINED,
                lw=2.4 if is_bound else 2.0, zorder=4 if is_bound else 3)
        # label up-and-right of each IC50 crossing: the curve descends away from
        # that quadrant, so the text never lands on its own line.
        # bare numbers only: the purple annotation block already names the bound,
        # and short labels cannot collide with each other.
        ax.annotate(f"{kd:.2g}", xy=(kd * (1.0 + A_LPS), 0.5),
                    textcoords="offset points", xytext=(24, 10),
                    ha="left", color=col, fontsize=8.2,
                    fontweight="bold" if is_bound else None, zorder=5)

    ax.axvline(C_V, color=style.C_THRESH, ls=style.LS_TIER4, lw=1.6, zorder=2)
    ax.text(C_V * 0.85, 0.015, f"dose tested: {C_V:g} $\\mu$M",
            color=style.C_THRESH, fontsize=8.2, ha="right", va="bottom",
            fontweight="bold")

    # the observation itself
    ax.errorbar(C_V, 1.0, yerr=[[F_DETECT_OCC], [0.0]], fmt="o", ms=9,
                color=style.C_DERIVED, ecolor=style.C_DERIVED, elinewidth=1.6,
                capsize=5, capthick=1.6, zorder=6, markeredgecolor="white",
                markeredgewidth=1.3)
    # above the band, where no curve reaches -- the marker sits directly below it
    ax.text(C_V, 1.047, "observed: v5, v14, v12, v16", ha="center", va="bottom",
            fontsize=8.0, color=style.C_DERIVED, zorder=6)

    ax.set_xscale("log")
    ax.set_xlim(0.1, 2500)
    ax.set_ylim(0, 1.105)
    ax.set_xlabel(r"[peptide] ($\mu$M)")
    ax.set_ylabel(r"normalised MFI  $\theta_{\mathrm{LPS}}(C)\,/\,\theta_{\mathrm{LPS}}(0)$")
    ax.set_title("A   Every variant was indistinguishable from LPS alone", loc="left")
    ax.grid(axis="x", visible=False)

    # the left column (x < ~5) is empty below y = 0.45 -- annotations go there
    ax.text(0.115, 0.335, r"curve labels: $K_{D,P}$ in $\mu$M",
            fontsize=8.0, color="#5A5A5A", va="center", ha="left")
    ax.text(0.115, 0.20,
            f"dashed = EXCLUDED by the\nobservation at {C_V:g} $\\mu$M\n\n"
            rf"$\Rightarrow\ K_{{D,P}} \geq {kd_bnd:.0f}\ \mu$M",
            fontsize=8.4, color=style.C_BAD, va="center", ha="left",
            linespacing=1.45)


def panel_b(ax):
    kd = np.logspace(np.log10(0.3), np.log10(60), 400)

    for tgt, lab, col in [(2.0, "50% suppression", style.C_V14),
                          (10.0, "90% suppression", style.C_BAD)]:
        need = np.array([dose_required(k, L_LPS, KD_L, 1.0, 1.0 / tgt) for k in kd])
        ax.plot(kd, need, color=col, lw=2.1)
        ax.text(kd[-1] * 1.06, need[-1], lab, color=col, fontsize=8.2,
                va="center", fontweight="bold")

    # solubility reference -- the loading demonstrated by the team (lower bound;
    # saturation solubility itself is still unmeasured)
    import params as _P
    _load = _P.C_LOAD_V14 / _P.UM
    ax.axhline(_load, color=style.C_THRESH, ls=style.LS_TIER4, lw=1.6)
    ax.text(0.33, _load * 1.12, f"{_load:.0f} µM -- 3 mg/mL loading demonstrated "
            "(saturation still UNMEASURED)",
            color=style.C_THRESH, fontsize=7.8, va="bottom", ha="left")

    _, kd_lo = kd_bound(F_DETECT_GATE)
    ax.axvspan(kd_lo, 60, color=style.C_BAD, alpha=0.10, zorder=0)
    ax.text(kd_lo * 1.12, 2.2, f"region allowed\nby the panel\n"
            rf"($K_{{D,P}} \geq {kd_lo:.0f}\ \mu$M)",
            color=style.C_BAD, fontsize=8.2, va="bottom", ha="left", linespacing=1.4)
    ax.axvline(kd_lo, color=style.C_BAD, lw=1.4, ls=(0, (5, 1.6)))

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(0.3, 60)
    ax.set_ylim(1, 1e5)
    ax.set_xlabel(r"$K_{D,P}$ ($\mu$M)")
    ax.set_ylabel(r"required tissue [V14] ($\mu$M)")
    ax.set_title("B   What that bound costs the delivery arm", loc="left")
    ax.grid(axis="x", visible=False)


def main():
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(12.0, 5.0),
                                   gridspec_kw={"width_ratios": [1.18, 1]})
    panel_a(axA)
    panel_b(axB)

    fig.text(0.5, -0.045,
             rf"$[L] = {L_LPS:g}\ \mu$M, $K_{{D,L}} = {KD_L * 1000:g}$ nM "
             rf"$\Rightarrow a = {A_LPS:.1f}$.  "
             r"Bound is ONE-SIDED: the data are equally consistent with no specific "
             r"binding, so $K_{D,P} \geq$ X is not an estimate of $K_{D,P}$."
             "\nIC$_{50}$ bound is independent of $a$; the $K_{D,P}$ conversion "
             r"divides by $(1+a)$ and inherits $K_{D,L}$'s Tier-3 uncertainty.",
             ha="center", va="top", fontsize=7.6, color="#777777", style="italic")

    fig.tight_layout(w_pad=3.4)
    out = os.path.join(_HERE, "WL_kdp_bound_25uM.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    print(f"wrote {out}\n")

    for f in (0.10, 0.20, 0.30, 0.50):
        ic, kd = kd_bound(f)
        print(f"  hide {f:.0%}:  IC50 >= {ic:7.1f} uM   K_D,P >= {kd:6.2f} uM")
    _, kd_lo = kd_bound(F_DETECT_GATE)
    print(f"\n  at K_D,P >= {kd_lo:.1f} uM the device needs")
    for tgt, lab in [(2.0, "50%"), (10.0, "90%")]:
        print(f"    {lab} suppression -> "
              f"{dose_required(kd_lo, L_LPS, KD_L, 1.0, 1.0 / tgt):8.1f} uM in tissue")

    # What to carry into the rest of the project. The team rounds these before
    # adopting them (see the comment on F_DETECT_GATE); CLAUDE.md at the project
    # root lists every place they must then be copied, in order.
    occ = occupancy_from_gate(F_DETECT_GATE, SIGMA_LOG, F_LPS_GATE, F_BG_GATE)
    target = kd_lo * (A_LPS - 1.0)
    print("\n  ---- TO ADOPT (after the team agrees the rounding) ----")
    print(f"  occupancy drop at the detection limit : {occ:.1%}")
    print(f"  params.py   KD_P_LOWER   = {kd_lo:.2f} * UM")
    print(f"  params.py   C_TARGET_V14 = {target:.1f} * UM      # = K_D,P (a - 1), a = {A_LPS:.2f}")
    print(f"  sim.js P    KD_P_UM: {kd_lo:.2f}, TARGET_UM: {target:.1f}, PANEL_DOSE_UM: {C_V:g}")
    print(f"  register    8_model7_design!C2 = {target:.1f}  (both copies)")
    print(f"  (psi_50 = 1 + a would give {kd_lo * (1.0 + A_LPS):.1f} uM)")


if __name__ == "__main__":
    main()
