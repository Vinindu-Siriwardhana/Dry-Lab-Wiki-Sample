"""
WL_positive_gate_trials2_3.py -- wet-lab FITC-LPS positive-gate frequency, trials 2 & 3.

Replaces the bar chart that came back from the wet lab (WhatsApp 2026-10-14). Changes:

  * mean +/- SD instead of bare bars, every replicate shown;
  * marker shape carries the trial, so the trial 2 / trial 3 offset is visible;
  * panel B normalises each sample to its own trial's LPS-alone mean, which removes
    that offset and shows the peptide effect on a like-for-like scale;
  * stats are labelled for what they are: raw Student p (as in the wet-lab CSV),
    Dunnett p (multiplicity-corrected vs LPS alone), and a trial-adjusted p
    (OLS: frequency ~ treatment + trial). All exploratory -- Trial 2 duplicates
    share a specimen and may be technical, not biological, replicates.

Reads trials2_3_positive_gate_frequency_raw_data.csv from the project root.

HKU iGEM 2026 Dry Lab.
"""

import csv
import os
import sys

import numpy as np
from scipy import stats

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
# ./model in the project tree; one level up in the distributed code bundle
sys.path.insert(0, os.path.join(_HERE, "model"))
sys.path.insert(0, _ROOT)

import style                       # noqa: E402
import matplotlib.pyplot as plt    # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

style.apply()

RAW = os.path.join(_ROOT, "Wet Lab Data", "trials2_3_positive_gate_frequency_raw_data.csv")
CONTROL = "FITC-LPS"
ORDER = ["Viability-only", "FITC-LPS", "v14", "v12", "v16"]
LABEL = {"Viability-only": "Viability\nonly", "FITC-LPS": "FITC-LPS\nalone",
         "v14": "FITC-LPS\n+ v14", "v12": "FITC-LPS\n+ v12", "v16": "FITC-LPS\n+ v16"}
COLOUR = {"Viability-only": style.C_GREY, "FITC-LPS": style.C_DERIVED,
          "v14": style.C_V14, "v12": style.C_V14, "v16": style.C_V14}
MARKER = {2: "o", 3: "^"}
PEPTIDES = ["v14", "v12", "v16"]


def load():
    data = {}
    with open(RAW, newline="") as fh:
        for r in csv.DictReader(fh):
            data.setdefault(r["treatment"], []).append(
                (int(r["trial_number"]), float(r["positive_gate_frequency_pct"])))
    return data


def trial_adjusted_p(data, trt):
    """OLS y ~ 1 + is_treatment + is_trial3 on treatment + control samples."""
    rows = [(t == trt, tr == 3, y) for t in (trt, CONTROL) for tr, y in data[t]]
    X = np.array([[1.0, a, b] for a, b, _ in rows])
    y = np.array([r[2] for r in rows])
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    resid = y - X @ beta
    dof = len(y) - X.shape[1]
    se = np.sqrt(resid @ resid / dof * np.linalg.inv(X.T @ X)[1, 1])
    return 2 * stats.t.sf(abs(beta[1] / se), dof)


def normalise(data):
    """Each sample as % of its own trial's LPS-alone mean."""
    ref = {tr: np.mean([y for t2, y in data[CONTROL] if t2 == tr])
           for tr in {tr for tr, _ in data[CONTROL]}}
    return {t: [(tr, 100 * y / ref[tr]) for tr, y in v] for t, v in data.items()}


def top(ys):
    """Highest drawn element of a group: a point or the upper SD cap."""
    ys = np.asarray(ys)
    return max(ys.max(), ys.mean() + ys.std(ddof=1))


def fmt_p(p):
    return "p < 0.001" if p < 0.001 else f"p = {p:.2f}"


def strip(ax, data, groups):
    rng = np.random.default_rng(7)
    for i, g in enumerate(groups):
        ys = np.array([y for _, y in data[g]])
        m, sd = ys.mean(), ys.std(ddof=1)
        ax.errorbar(i, m, yerr=sd, fmt="none", ecolor=COLOUR[g], elinewidth=1.4,
                    capsize=5, capthick=1.4, zorder=2)
        ax.hlines(m, i - 0.28, i + 0.28, color=COLOUR[g], lw=2.6, zorder=3)
        for tr, y in data[g]:
            ax.scatter(i + rng.uniform(-0.13, 0.13), y, s=46, marker=MARKER[tr],
                       facecolor=COLOUR[g], edgecolor="white", linewidth=1.2,
                       zorder=4)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels([LABEL[g] for g in groups])
    ax.set_xlim(-0.6, len(groups) - 0.4)
    ax.grid(axis="x", visible=False)


def main():
    data = load()
    L = [y for _, y in data[CONTROL]]
    dunnett = dict(zip(PEPTIDES, stats.dunnett(
        *[[y for _, y in data[g]] for g in PEPTIDES], control=L).pvalue))
    student = {g: stats.ttest_ind([y for _, y in data[g]], L).pvalue
               for g in ["Viability-only"] + PEPTIDES}
    adj = {g: trial_adjusted_p(data, g) for g in PEPTIDES}

    fig, (axA, axB) = plt.subplots(1, 2, figsize=(11.2, 4.9),
                                   gridspec_kw={"width_ratios": [5, 4]})

    # ---- A: raw frequency ---------------------------------------------------
    strip(axA, data, ORDER)
    axA.set_ylim(0, 24.5)
    axA.set_ylabel("FITC-LPS$^+$ cells (% of live gate)")
    axA.set_title("A   Positive-gate frequency", loc="left")
    axA.text(0, 3.2, f"vs LPS alone\nStudent {fmt_p(student['Viability-only'])}",
             ha="center", va="bottom", fontsize=7.8, color="#444444")
    for i, g in enumerate(PEPTIDES, start=2):
        ys = [y for _, y in data[g]]
        d = np.mean(ys) - np.mean(L)
        axA.text(i, top(ys) + 0.6,
                 f"{d:+.1f} pp\nStudent {fmt_p(student[g])}\n"
                 f"Dunnett {fmt_p(dunnett[g])}",
                 ha="center", va="bottom", fontsize=7.8, color="#444444")

    # ---- B: normalised to same-trial LPS alone -----------------------------
    norm = normalise(data)
    groups_b = [CONTROL] + PEPTIDES
    strip(axB, norm, groups_b)
    axB.axhline(100, color=style.C_DERIVED, lw=0.9, ls=":", zorder=1)
    axB.set_ylim(60, 152)
    axB.set_ylabel("% of same-trial LPS-alone mean")
    axB.set_title("B   Normalised within trial", loc="left")
    for i, g in enumerate(PEPTIDES, start=1):
        ys = [y for _, y in norm[g]]
        axB.text(i, top(ys) + 2.5, f"{np.mean(ys) - 100:+.0f}%\ntrial-adj. {fmt_p(adj[g])}",
                 ha="center", va="bottom", fontsize=7.8, color="#444444")

    # ---- shared legend + caveat ---------------------------------------------
    handles = [Line2D([], [], marker=MARKER[t], ls="none", markersize=7,
                      markerfacecolor="#777777", markeredgecolor="white",
                      label=f"Trial {t}") for t in (2, 3)]
    handles.append(Line2D([], [], color="#777777", lw=2.4,
                          label="mean $\\pm$ SD (n = 3: Trial 2 ×2, Trial 3 ×1)"))
    fig.legend(handles=handles, loc="lower center", ncol=3,
               bbox_to_anchor=(0.5, -0.06))
    fig.text(0.5, -0.075,
             "Exploratory. Student / Dunnett: vs FITC-LPS alone, df = 4. Trial-adjusted: "
             "OLS frequency ~ treatment + trial on that pair.\nTrial 2 duplicates come from "
             "one specimen; if they are technical replicates the effective n is 2 trials.",
             ha="center", va="top", fontsize=7.5, color="#777777", style="italic")

    fig.tight_layout()
    out = os.path.join(_HERE, "WL_positive_gate_trials2_3.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    print(f"wrote {out}")
    for g in PEPTIDES:
        print(f"  {g}: Student {student[g]:.3g}  Dunnett "
              f"{dunnett[g]:.3g}  trial-adj {adj[g]:.3g}")


if __name__ == "__main__":
    main()
