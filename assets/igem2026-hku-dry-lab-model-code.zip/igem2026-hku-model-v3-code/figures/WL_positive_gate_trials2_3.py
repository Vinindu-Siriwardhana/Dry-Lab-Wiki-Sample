"""Plot current Specimens 3/7 data with V12 and V16 from Trials 2/3.

The cohorts stay visibly separate. The normalized panel uses each new specimen's
own LPS-alone mean and each historical trial's own LPS-alone mean.
"""

import csv
import os
import sys

import numpy as np
from scipy import stats

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, os.path.join(_HERE, "model"))

import style  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

style.apply()

RAW_NEW = os.path.join(_ROOT, "Wet Lab Data", "specimen3_7_ctrl_lps_v14_v5_raw_data.csv")
RAW_OLD = os.path.join(_ROOT, "Wet Lab Data", "trials2_3_positive_gate_frequency_raw_data.csv")
GROUPS = ["new_viability", "new_lps", "new_v14", "new_v5",
          "old_lps", "old_v12", "old_v16"]
LABEL = {"new_viability": "Viability\nonly", "new_lps": "FITC-LPS\nalone",
         "new_v14": "V14\n(new)", "new_v5": "V5\n(new)",
         "old_lps": "FITC-LPS\nalone", "old_v12": "V12\n(earlier)",
         "old_v16": "V16\n(earlier)"}
COLOUR = {"new_viability": style.C_GREY, "new_lps": style.C_DERIVED,
          "new_v14": style.C_V14, "new_v5": style.C_FGF,
          "old_lps": style.C_DERIVED, "old_v12": style.C_V14_L,
          "old_v16": style.C_BAD}
MARKER = {("new", "Specimen3"): "o", ("new", "Specimen7"): "^",
          ("old", 2): "s", ("old", 3): "D"}


def load():
    data = {g: [] for g in GROUPS}
    with open(RAW_NEW, newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            key = {"Viability-only": "new_viability", "FITC-LPS": "new_lps",
                   "v14": "new_v14", "v5": "new_v5"}.get(row["treatment"])
            if key:
                data[key].append(("new", row["specimen"],
                                  float(row["positive_gate_frequency_pct"])))
    with open(RAW_OLD, newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            key = {"FITC-LPS": "old_lps", "v12": "old_v12",
                   "v16": "old_v16"}.get(row["treatment"])
            if key:
                data[key].append(("old", int(row["trial_number"]),
                                  float(row["positive_gate_frequency_pct"])))
    return data


def reference_mean(data, source, replicate):
    control = "new_lps" if source == "new" else "old_lps"
    return np.mean([y for src, rep, y in data[control]
                    if src == source and rep == replicate])


def normalise(data):
    return {group: [(src, rep, 100 * y / reference_mean(data, src, rep))
                    for src, rep, y in values]
            for group, values in data.items()}


def top(ys):
    ys = np.asarray(ys)
    return max(ys.max(), ys.mean() + ys.std(ddof=1))


def fmt_p(p):
    return "p < 0.001" if p < 0.001 else f"p = {p:.3f}"


def student_p(data, group, control):
    return stats.ttest_ind([y for _, _, y in data[group]],
                           [y for _, _, y in data[control]]).pvalue


def strip(ax, data, groups):
    rng = np.random.default_rng(7)
    for i, group in enumerate(groups):
        values = np.asarray([y for _, _, y in data[group]])
        mean, sd = values.mean(), values.std(ddof=1)
        ax.errorbar(i, mean, yerr=sd, fmt="none", ecolor=COLOUR[group],
                    elinewidth=1.4, capsize=4, capthick=1.3, zorder=2)
        ax.hlines(mean, i - 0.23, i + 0.23, color=COLOUR[group], lw=2.5, zorder=3)
        for source, replicate, y in data[group]:
            ax.scatter(i + rng.uniform(-0.11, 0.11), y, s=45,
                       marker=MARKER[(source, replicate)], facecolor=COLOUR[group],
                       edgecolor="white", linewidth=1.0, zorder=4)
    ax.set_xticks(range(len(groups)), [LABEL[g] for g in groups])
    ax.set_xlim(-0.55, len(groups) - 0.45)
    ax.grid(axis="x", visible=False)


def main():
    data = load()
    new_means = {g: np.mean([y for _, _, y in data[g]])
                 for g in ("new_viability", "new_lps", "new_v14", "new_v5")}
    old_means = {g: np.mean([y for _, _, y in data[g]])
                 for g in ("old_lps", "old_v12", "old_v16")}
    p = {"new_viability": student_p(data, "new_viability", "new_lps"),
         "new_v14": student_p(data, "new_v14", "new_lps"),
         "new_v5": student_p(data, "new_v5", "new_lps"),
         "old_v12": student_p(data, "old_v12", "old_lps"),
         "old_v16": student_p(data, "old_v16", "old_lps")}

    fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(12.0, 4.9),
                                     gridspec_kw={"width_ratios": [1.15, 1]})
    strip(ax_a, data, GROUPS)
    ax_a.set_ylim(0, 25)
    ax_a.set_ylabel("FITC-LPS$^+$ cells (% of live gate)")
    ax_a.set_title("A   Positive-gate frequency", loc="left")
    ax_a.axvline(3.5, color="#999999", lw=1, ls="--")
    ax_a.text(1.5, 24.0, "New Specimens 3/7", ha="center", va="top",
              fontsize=8, color="#555555")
    ax_a.text(5.0, 24.0, "Earlier Trials 2/3", ha="center", va="top",
              fontsize=8, color="#555555")
    for group, means, control in [
        ("new_v14", new_means, "new_lps"), ("new_v5", new_means, "new_lps"),
        ("old_v12", old_means, "old_lps"), ("old_v16", old_means, "old_lps")]:
        i = GROUPS.index(group)
        delta = means[group] - means[control]
        ax_a.text(i, top([y for _, _, y in data[group]]) + 0.5,
                  f"{delta:+.1f} pp\n{fmt_p(p[group])}",
                  ha="center", va="bottom", fontsize=7.2, color="#444444")

    norm = normalise(data)
    strip(ax_b, norm, GROUPS)
    ax_b.axhline(100, color=style.C_DERIVED, lw=0.9, ls=":", zorder=1)
    ax_b.axvline(3.5, color="#999999", lw=1, ls="--")
    ax_b.set_ylim(0, 160)
    ax_b.set_ylabel("% of matched LPS-alone mean")
    ax_b.set_title("B   Normalised within specimen / trial", loc="left")

    markers = [("new", "Specimen3", "Specimen 3"),
               ("new", "Specimen7", "Specimen 7"),
               ("old", 2, "Trial 2"), ("old", 3, "Trial 3")]
    handles = [Line2D([], [], marker=MARKER[(src, rep)], ls="none", markersize=6.5,
                      markerfacecolor="#777777", markeredgecolor="white", label=label)
               for src, rep, label in markers]
    handles.append(Line2D([], [], color="#777777", lw=2.4,
                          label="mean ± SD; points are sample-level observations"))
    fig.legend(handles=handles, loc="lower center", ncol=5,
               bbox_to_anchor=(0.5, -0.005), fontsize=7.5)
    fig.text(0.5, -0.045,
             "Exploratory, unadjusted Student t-tests vs the matching cohort control. "
             "New groups: n=4 each (1 Specimen 3, 3 Specimen 7); earlier V12/V16: n=3 each "
             "(Trial 2 duplicates share Specimen 4; Trial 3 is Specimen 6). "
             "Raw frequencies across cohorts are not directly comparable.",
             ha="center", va="top", fontsize=7.1, color="#777777", style="italic")
    fig.tight_layout(rect=(0, 0.08, 1, 1))

    local_out = os.path.join(_HERE, "WL_positive_gate_trials2_3.png")
    wiki_dir = os.path.join(_ROOT, "_remote_check", "assets")
    os.makedirs(wiki_dir, exist_ok=True)
    fig.savefig(local_out, dpi=200, bbox_inches="tight")
    fig.savefig(os.path.join(wiki_dir, "WL_positive_gate_trials2_3.png"),
                dpi=200, bbox_inches="tight")
    print(f"wrote {local_out}")
    print("new cohort means:", ", ".join(f"{g}={v:.3f}%" for g, v in new_means.items()))
    print("earlier cohort means:", ", ".join(f"{g}={v:.3f}%" for g, v in old_means.items()))
    print("unadjusted Student p-values:", ", ".join(f"{g} {fmt_p(v)}" for g, v in p.items()))


if __name__ == "__main__":
    main()
