"""G12 -- prediction uncertainty: probability that the wound has closed by day t under the
joint Model 6 prior (sa_run.PRIORS_B, Monte Carlo, analytic front-speed surrogate)."""
import numpy as np
from common import *
import sa_run

rng = np.random.default_rng(3)
N = 20000
X = sa_run._scale(rng.random((N, len(sa_run.PRIORS_B))), sa_run.PRIORS_B)
tc, stalled = sa_run.model_B(X)
tc = np.where(stalled | (tc >= sa_run.CAP_DAYS), np.inf, tc)
t = np.linspace(0, 120, 600)
p = np.array([(tc <= x).mean() for x in t])
q = np.percentile(tc[np.isfinite(tc)], [25, 50, 75])

fig, ax = plt.subplots(figsize=(6.8, 4.1))
ax.plot(t, p * 100, color=S.C_FGF, lw=2.2, ls=S.LS_TIER4)
ax.axhline((~stalled).mean() * 100, color=S.C_BAD, lw=1, ls=":")
ax.text(118, (~stalled).mean() * 100 + 2, f"plateau: {(~stalled).mean():.0%} of samples have $r_p > d$",
        ha="right", fontsize=8.2, color=S.C_BAD, weight="bold")
for x, lab in zip(q, ("25th", "median", "75th")):
    y = np.interp(x, t, p * 100)
    ax.plot(x, y, "o", color=S.C_FGF, ms=6, mec="white", mew=1.2)
    ax.annotate(f"{lab} of closing\nsamples: {x:.0f} d", (x, y), textcoords="offset points",
                xytext=(8, -22), fontsize=7.6, color="#444444")
ax.set_xlim(0, 120); ax.set_ylim(0, 100)
ax.set_xlabel("days after treatment start")
ax.set_ylabel("% of parameter samples closed")
ax.set_title(f"Predicted closure time across the joint parameter prior  "
             f"($R_w$ = {P.R_W_DEFAULT*10:.0f} mm)", fontsize=10)
fig.text(0.02, -0.02, f"Monte Carlo, N = {N:,}, log-uniform priors on all 10 Model 6 parameters "
         "(every one Tier 4); closure from the pulled-front speed surrogate in sa_run.py.\n"
         "Closure = fibroblast front reaching the wound centre in the model, not complete skin healing.",
         fontsize=7.4, color="#555555", va="top")
save(fig, "G12_closure_prediction_uncertainty")
print(stalled.mean(), q)
